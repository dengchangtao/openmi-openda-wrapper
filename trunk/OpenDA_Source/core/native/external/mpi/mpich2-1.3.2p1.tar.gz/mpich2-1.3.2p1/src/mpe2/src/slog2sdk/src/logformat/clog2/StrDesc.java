/*
 *  (C) 2001 by Argonne National Laboratory
 *      See COPYRIGHT in top-level directory.
 */

/*
 *  @author  Anthony Chan
 */

package logformat.clog2;

// specify the logfile bytesize of CLOG_STR_DESC
class StrDesc
{
    public static final int BYTESIZE = 4 * 8;
}
