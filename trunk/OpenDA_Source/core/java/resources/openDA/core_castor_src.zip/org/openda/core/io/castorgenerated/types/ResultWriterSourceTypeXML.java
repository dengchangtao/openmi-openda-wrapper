/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class ResultWriterSourceTypeXML.
 * 
 * @version $Revision$ $Date$
 */
public class ResultWriterSourceTypeXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The stochasticModel type
     */
    public static final int STOCHASTICMODEL_TYPE = 0;

    /**
     * The instance of the stochasticModel type
     */
    public static final ResultWriterSourceTypeXML STOCHASTICMODEL = new ResultWriterSourceTypeXML(STOCHASTICMODEL_TYPE, "stochasticModel");

    /**
     * The stochModel type
     */
    public static final int STOCHMODEL_TYPE = 1;

    /**
     * The instance of the stochModel type
     */
    public static final ResultWriterSourceTypeXML STOCHMODEL = new ResultWriterSourceTypeXML(STOCHMODEL_TYPE, "stochModel");

    /**
     * The model type
     */
    public static final int MODEL_TYPE = 2;

    /**
     * The instance of the model type
     */
    public static final ResultWriterSourceTypeXML MODEL = new ResultWriterSourceTypeXML(MODEL_TYPE, "model");

    /**
     * The alg type
     */
    public static final int ALG_TYPE = 3;

    /**
     * The instance of the alg type
     */
    public static final ResultWriterSourceTypeXML ALG = new ResultWriterSourceTypeXML(ALG_TYPE, "alg");

    /**
     * The algorithm type
     */
    public static final int ALGORITHM_TYPE = 4;

    /**
     * The instance of the algorithm type
     */
    public static final ResultWriterSourceTypeXML ALGORITHM = new ResultWriterSourceTypeXML(ALGORITHM_TYPE, "algorithm");

    /**
     * The stochasticObserver type
     */
    public static final int STOCHASTICOBSERVER_TYPE = 5;

    /**
     * The instance of the stochasticObserver type
     */
    public static final ResultWriterSourceTypeXML STOCHASTICOBSERVER = new ResultWriterSourceTypeXML(STOCHASTICOBSERVER_TYPE, "stochasticObserver");

    /**
     * The stochObserver type
     */
    public static final int STOCHOBSERVER_TYPE = 6;

    /**
     * The instance of the stochObserver type
     */
    public static final ResultWriterSourceTypeXML STOCHOBSERVER = new ResultWriterSourceTypeXML(STOCHOBSERVER_TYPE, "stochObserver");

    /**
     * The observer type
     */
    public static final int OBSERVER_TYPE = 7;

    /**
     * The instance of the observer type
     */
    public static final ResultWriterSourceTypeXML OBSERVER = new ResultWriterSourceTypeXML(OBSERVER_TYPE, "observer");

    /**
     * The other type
     */
    public static final int OTHER_TYPE = 8;

    /**
     * The instance of the other type
     */
    public static final ResultWriterSourceTypeXML OTHER = new ResultWriterSourceTypeXML(OTHER_TYPE, "other");

    /**
     * Field _memberTable
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type
     */
    private int type = -1;

    /**
     * Field stringValue
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private ResultWriterSourceTypeXML(int type, java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML(int, java.lang.String)


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerateReturns an enumeration of all possible
     * instances of ResultWriterSourceTypeXML
     */
    public static java.util.Enumeration enumerate()
    {
        return _memberTable.elements();
    } //-- java.util.Enumeration enumerate() 

    /**
     * Method getTypeReturns the type of this
     * ResultWriterSourceTypeXML
     */
    public int getType()
    {
        return this.type;
    } //-- int getType() 

    /**
     * Method init
     */
    private static java.util.Hashtable init()
    {
        Hashtable members = new Hashtable();
        members.put("stochasticModel", STOCHASTICMODEL);
        members.put("stochModel", STOCHMODEL);
        members.put("model", MODEL);
        members.put("alg", ALG);
        members.put("algorithm", ALGORITHM);
        members.put("stochasticObserver", STOCHASTICOBSERVER);
        members.put("stochObserver", STOCHOBSERVER);
        members.put("observer", OBSERVER);
        members.put("other", OTHER);
        return members;
    } //-- java.util.Hashtable init() 

    /**
     * Method toStringReturns the String representation of this
     * ResultWriterSourceTypeXML
     */
    public java.lang.String toString()
    {
        return this.stringValue;
    } //-- java.lang.String toString() 

    /**
     * Method valueOfReturns a new ResultWriterSourceTypeXML based
     * on the given String value.
     * 
     * @param string
     */
    public static org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML valueOf(java.lang.String string)
    {
        java.lang.Object obj = null;
        if (string != null) obj = _memberTable.get(string);
        if (obj == null) {
            String err = "'" + string + "' is not a valid ResultWriterSourceTypeXML";
            throw new IllegalArgumentException(err);
        }
        return (ResultWriterSourceTypeXML) obj;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML valueOf(java.lang.String) 

}
