/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ResultLoggingXML.
 * 
 * @version $Revision$ $Date$
 */
public class ResultLoggingXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Output source is observer
     */
    private boolean _observer = true;

    /**
     * keeps track of state for field: _observer
     */
    private boolean _has_observer;

    /**
     * Output source is model
     */
    private boolean _model = true;

    /**
     * keeps track of state for field: _model
     */
    private boolean _has_model;

    /**
     * Output source is algorithm
     */
    private boolean _algorithm = true;

    /**
     * keeps track of state for field: _algorithm
     */
    private boolean _has_algorithm;

    /**
     * Output source is other non-declared component
     */
    private boolean _nonConfiguredItems = true;

    /**
     * keeps track of state for field: _nonConfiguredItems
     */
    private boolean _has_nonConfiguredItems;


      //----------------/
     //- Constructors -/
    //----------------/

    public ResultLoggingXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.ResultLoggingXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteAlgorithm
     */
    public void deleteAlgorithm()
    {
        this._has_algorithm= false;
    } //-- void deleteAlgorithm() 

    /**
     * Method deleteModel
     */
    public void deleteModel()
    {
        this._has_model= false;
    } //-- void deleteModel() 

    /**
     * Method deleteNonConfiguredItems
     */
    public void deleteNonConfiguredItems()
    {
        this._has_nonConfiguredItems= false;
    } //-- void deleteNonConfiguredItems() 

    /**
     * Method deleteObserver
     */
    public void deleteObserver()
    {
        this._has_observer= false;
    } //-- void deleteObserver() 

    /**
     * Returns the value of field 'algorithm'. The field
     * 'algorithm' has the following description: Output source is
     * algorithm
     * 
     * @return the value of field 'algorithm'.
     */
    public boolean getAlgorithm()
    {
        return this._algorithm;
    } //-- boolean getAlgorithm() 

    /**
     * Returns the value of field 'model'. The field 'model' has
     * the following description: Output source is model
     * 
     * @return the value of field 'model'.
     */
    public boolean getModel()
    {
        return this._model;
    } //-- boolean getModel() 

    /**
     * Returns the value of field 'nonConfiguredItems'. The field
     * 'nonConfiguredItems' has the following description: Output
     * source is other non-declared component
     * 
     * @return the value of field 'nonConfiguredItems'.
     */
    public boolean getNonConfiguredItems()
    {
        return this._nonConfiguredItems;
    } //-- boolean getNonConfiguredItems() 

    /**
     * Returns the value of field 'observer'. The field 'observer'
     * has the following description: Output source is observer
     * 
     * @return the value of field 'observer'.
     */
    public boolean getObserver()
    {
        return this._observer;
    } //-- boolean getObserver() 

    /**
     * Method hasAlgorithm
     */
    public boolean hasAlgorithm()
    {
        return this._has_algorithm;
    } //-- boolean hasAlgorithm() 

    /**
     * Method hasModel
     */
    public boolean hasModel()
    {
        return this._has_model;
    } //-- boolean hasModel() 

    /**
     * Method hasNonConfiguredItems
     */
    public boolean hasNonConfiguredItems()
    {
        return this._has_nonConfiguredItems;
    } //-- boolean hasNonConfiguredItems() 

    /**
     * Method hasObserver
     */
    public boolean hasObserver()
    {
        return this._has_observer;
    } //-- boolean hasObserver() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'algorithm'. The field 'algorithm'
     * has the following description: Output source is algorithm
     * 
     * @param algorithm the value of field 'algorithm'.
     */
    public void setAlgorithm(boolean algorithm)
    {
        this._algorithm = algorithm;
        this._has_algorithm = true;
    } //-- void setAlgorithm(boolean) 

    /**
     * Sets the value of field 'model'. The field 'model' has the
     * following description: Output source is model
     * 
     * @param model the value of field 'model'.
     */
    public void setModel(boolean model)
    {
        this._model = model;
        this._has_model = true;
    } //-- void setModel(boolean) 

    /**
     * Sets the value of field 'nonConfiguredItems'. The field
     * 'nonConfiguredItems' has the following description: Output
     * source is other non-declared component
     * 
     * @param nonConfiguredItems the value of field
     * 'nonConfiguredItems'.
     */
    public void setNonConfiguredItems(boolean nonConfiguredItems)
    {
        this._nonConfiguredItems = nonConfiguredItems;
        this._has_nonConfiguredItems = true;
    } //-- void setNonConfiguredItems(boolean) 

    /**
     * Sets the value of field 'observer'. The field 'observer' has
     * the following description: Output source is observer
     * 
     * @param observer the value of field 'observer'.
     */
    public void setObserver(boolean observer)
    {
        this._observer = observer;
        this._has_observer = true;
    } //-- void setObserver(boolean) 

    /**
     * Method unmarshalResultLoggingXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ResultLoggingXML unmarshalResultLoggingXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ResultLoggingXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ResultLoggingXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ResultLoggingXML unmarshalResultLoggingXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
