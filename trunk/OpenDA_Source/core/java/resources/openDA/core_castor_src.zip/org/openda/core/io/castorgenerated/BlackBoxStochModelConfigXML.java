/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify either a black box model or a black box model factory
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice _blackBoxStochModelConfigXMLChoice;

    /**
     * Define stochastic model through an uncertainty module.
     * Specify class or executable file, arguments to supply and
     * fail/success checks to perform. Use of this element is
     * discouraged, use vectorSpecification -> parameters ->
     * uncertaintyModule instead.
     */
    private org.openda.core.io.castorgenerated.ActionXML _uncertaintyModule;

    /**
     * Define stochastic model by specifying the vectors of
     * parameters, state, and/or predictor
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML _vectorSpecification;

    /**
     * Restart dir./files information
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML _restartInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelConfigXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field
     * 'blackBoxStochModelConfigXMLChoice'. The field
     * 'blackBoxStochModelConfigXMLChoice' has the following
     * description: Specify either a black box model or a black box
     * model factory
     * 
     * @return the value of field
     * 'blackBoxStochModelConfigXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice getBlackBoxStochModelConfigXMLChoice()
    {
        return this._blackBoxStochModelConfigXMLChoice;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice getBlackBoxStochModelConfigXMLChoice() 

    /**
     * Returns the value of field 'restartInfo'. The field
     * 'restartInfo' has the following description: Restart
     * dir./files information
     * 
     * @return the value of field 'restartInfo'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML getRestartInfo()
    {
        return this._restartInfo;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML getRestartInfo() 

    /**
     * Returns the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: Define
     * stochastic model through an uncertainty module. Specify
     * class or executable file, arguments to supply and
     * fail/success checks to perform. Use of this element is
     * discouraged, use vectorSpecification -> parameters ->
     * uncertaintyModule instead.
     * 
     * @return the value of field 'uncertaintyModule'.
     */
    public org.openda.core.io.castorgenerated.ActionXML getUncertaintyModule()
    {
        return this._uncertaintyModule;
    } //-- org.openda.core.io.castorgenerated.ActionXML getUncertaintyModule() 

    /**
     * Returns the value of field 'vectorSpecification'. The field
     * 'vectorSpecification' has the following description: Define
     * stochastic model by specifying the vectors of parameters,
     * state, and/or predictor
     * 
     * @return the value of field 'vectorSpecification'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML getVectorSpecification()
    {
        return this._vectorSpecification;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML getVectorSpecification() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'blackBoxStochModelConfigXMLChoice'.
     * The field 'blackBoxStochModelConfigXMLChoice' has the
     * following description: Specify either a black box model or a
     * black box model factory
     * 
     * @param blackBoxStochModelConfigXMLChoice the value of field
     * 'blackBoxStochModelConfigXMLChoice'.
     */
    public void setBlackBoxStochModelConfigXMLChoice(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice blackBoxStochModelConfigXMLChoice)
    {
        this._blackBoxStochModelConfigXMLChoice = blackBoxStochModelConfigXMLChoice;
    } //-- void setBlackBoxStochModelConfigXMLChoice(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXMLChoice) 

    /**
     * Sets the value of field 'restartInfo'. The field
     * 'restartInfo' has the following description: Restart
     * dir./files information
     * 
     * @param restartInfo the value of field 'restartInfo'.
     */
    public void setRestartInfo(org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML restartInfo)
    {
        this._restartInfo = restartInfo;
    } //-- void setRestartInfo(org.openda.core.io.castorgenerated.BlackBoxStochModelRestartInfoXML) 

    /**
     * Sets the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: Define
     * stochastic model through an uncertainty module. Specify
     * class or executable file, arguments to supply and
     * fail/success checks to perform. Use of this element is
     * discouraged, use vectorSpecification -> parameters ->
     * uncertaintyModule instead.
     * 
     * @param uncertaintyModule the value of field
     * 'uncertaintyModule'.
     */
    public void setUncertaintyModule(org.openda.core.io.castorgenerated.ActionXML uncertaintyModule)
    {
        this._uncertaintyModule = uncertaintyModule;
    } //-- void setUncertaintyModule(org.openda.core.io.castorgenerated.ActionXML) 

    /**
     * Sets the value of field 'vectorSpecification'. The field
     * 'vectorSpecification' has the following description: Define
     * stochastic model by specifying the vectors of parameters,
     * state, and/or predictor
     * 
     * @param vectorSpecification the value of field
     * 'vectorSpecification'.
     */
    public void setVectorSpecification(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML vectorSpecification)
    {
        this._vectorSpecification = vectorSpecification;
    } //-- void setVectorSpecification(org.openda.core.io.castorgenerated.BlackBoxStochModelVectorSpecificationXML) 

    /**
     * Method unmarshalBlackBoxStochModelConfigXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML unmarshalBlackBoxStochModelConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelConfigXML unmarshalBlackBoxStochModelConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
