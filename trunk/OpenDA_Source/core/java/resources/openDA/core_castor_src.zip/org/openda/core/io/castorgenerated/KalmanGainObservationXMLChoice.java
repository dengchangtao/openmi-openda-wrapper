/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class KalmanGainObservationXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class KalmanGainObservationXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The values of the kalman gain for this observation. This
     * optional field is only present if the size is limited
     * (default max 40 values; this maximum can be overridden by
     * the filter)
     */
    private java.lang.String _vector;

    /**
     * The values of the kalman gain for this observation,
     * represented as tree vector. Present if the size is limited
     * (see above)
     */
    private org.openda.core.io.castorgenerated.TreeVectorXML _treeVector;

    /**
     * The netCdfFile containing the values. This optional field is
     * present if the gain is at TreeVector, or if there are more
     * values than the maximum mentioned above
     */
    private java.lang.String _fileName;


      //----------------/
     //- Constructors -/
    //----------------/

    public KalmanGainObservationXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'fileName'. The field 'fileName'
     * has the following description: The netCdfFile containing the
     * values. This optional field is present if the gain is at
     * TreeVector, or if there are more values than the maximum
     * mentioned above
     * 
     * @return the value of field 'fileName'.
     */
    public java.lang.String getFileName()
    {
        return this._fileName;
    } //-- java.lang.String getFileName() 

    /**
     * Returns the value of field 'treeVector'. The field
     * 'treeVector' has the following description: The values of
     * the kalman gain for this observation, represented as tree
     * vector. Present if the size is limited (see above)
     * 
     * @return the value of field 'treeVector'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorXML getTreeVector()
    {
        return this._treeVector;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML getTreeVector() 

    /**
     * Returns the value of field 'vector'. The field 'vector' has
     * the following description: The values of the kalman gain for
     * this observation. This optional field is only present if the
     * size is limited (default max 40 values; this maximum can be
     * overridden by the filter)
     * 
     * @return the value of field 'vector'.
     */
    public java.lang.String getVector()
    {
        return this._vector;
    } //-- java.lang.String getVector() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'fileName'. The field 'fileName' has
     * the following description: The netCdfFile containing the
     * values. This optional field is present if the gain is at
     * TreeVector, or if there are more values than the maximum
     * mentioned above
     * 
     * @param fileName the value of field 'fileName'.
     */
    public void setFileName(java.lang.String fileName)
    {
        this._fileName = fileName;
    } //-- void setFileName(java.lang.String) 

    /**
     * Sets the value of field 'treeVector'. The field 'treeVector'
     * has the following description: The values of the kalman gain
     * for this observation, represented as tree vector. Present if
     * the size is limited (see above)
     * 
     * @param treeVector the value of field 'treeVector'.
     */
    public void setTreeVector(org.openda.core.io.castorgenerated.TreeVectorXML treeVector)
    {
        this._treeVector = treeVector;
    } //-- void setTreeVector(org.openda.core.io.castorgenerated.TreeVectorXML) 

    /**
     * Sets the value of field 'vector'. The field 'vector' has the
     * following description: The values of the kalman gain for
     * this observation. This optional field is only present if the
     * size is limited (default max 40 values; this maximum can be
     * overridden by the filter)
     * 
     * @param vector the value of field 'vector'.
     */
    public void setVector(java.lang.String vector)
    {
        this._vector = vector;
    } //-- void setVector(java.lang.String) 

    /**
     * Method unmarshalKalmanGainObservationXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice unmarshalKalmanGainObservationXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationXMLChoice unmarshalKalmanGainObservationXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
