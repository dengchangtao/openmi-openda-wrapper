/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class TimeZoneXML.
 * 
 * @version $Revision$ $Date$
 */
public class TimeZoneXML implements java.io.Serializable {


      //----------------/
     //- Constructors -/
    //----------------/

    public TimeZoneXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.TimeZoneXML()

}
