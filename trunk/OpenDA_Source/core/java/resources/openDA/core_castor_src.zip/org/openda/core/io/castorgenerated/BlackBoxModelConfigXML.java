/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxModelConfigXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxModelConfigXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify black box wrapper configuration that addresses the
     * deterministic model
     */
    private org.openda.core.io.castorgenerated.BlackBoxWrapperConfigReferenceXML _wrapperConfig;

    /**
     * Specify the actual values referred to by the alias keys
     * defined in the black box wrapper configuration
     */
    private org.openda.core.io.castorgenerated.AliasValuesXML _aliasValues;

    /**
     * Select one of the options
     */
    private org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice _blackBoxModelConfigXMLChoice;

    /**
     * Specify the list of items to exchange between the model and
     * OpenDA components. An exchange item may be defined either as
     * vector or subvector.
     */
    private org.openda.core.io.castorgenerated.ExchangeItemXML _exchangeItems;

    /**
     * Specify whether to remove unnecessary files upon completion
     * of a model run (boolean, optional)
     */
    private boolean _doCleanUp = false;

    /**
     * keeps track of state for field: _doCleanUp
     */
    private boolean _has_doCleanUp;

    /**
     * If set to true, no actions are executed on a model instance
     * that already exists (boolean, optional)
     */
    private boolean _skipModelActionsIfInstanceDirExists = false;

    /**
     * keeps track of state for field:
     * _skipModelActionsIfInstanceDirExists
     */
    private boolean _has_skipModelActionsIfInstanceDirExists;

    /**
     * Restart dir./files information.
     */
    private org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML _restartInfo;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxModelConfigXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelConfigXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteDoCleanUp
     */
    public void deleteDoCleanUp()
    {
        this._has_doCleanUp= false;
    } //-- void deleteDoCleanUp() 

    /**
     * Method deleteSkipModelActionsIfInstanceDirExists
     */
    public void deleteSkipModelActionsIfInstanceDirExists()
    {
        this._has_skipModelActionsIfInstanceDirExists= false;
    } //-- void deleteSkipModelActionsIfInstanceDirExists() 

    /**
     * Returns the value of field 'aliasValues'. The field
     * 'aliasValues' has the following description: Specify the
     * actual values referred to by the alias keys defined in the
     * black box wrapper configuration
     * 
     * @return the value of field 'aliasValues'.
     */
    public org.openda.core.io.castorgenerated.AliasValuesXML getAliasValues()
    {
        return this._aliasValues;
    } //-- org.openda.core.io.castorgenerated.AliasValuesXML getAliasValues() 

    /**
     * Returns the value of field 'blackBoxModelConfigXMLChoice'.
     * The field 'blackBoxModelConfigXMLChoice' has the following
     * description: Select one of the options
     * 
     * @return the value of field 'blackBoxModelConfigXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice getBlackBoxModelConfigXMLChoice()
    {
        return this._blackBoxModelConfigXMLChoice;
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice getBlackBoxModelConfigXMLChoice() 

    /**
     * Returns the value of field 'doCleanUp'. The field
     * 'doCleanUp' has the following description: Specify whether
     * to remove unnecessary files upon completion of a model run
     * (boolean, optional)
     * 
     * @return the value of field 'doCleanUp'.
     */
    public boolean getDoCleanUp()
    {
        return this._doCleanUp;
    } //-- boolean getDoCleanUp() 

    /**
     * Returns the value of field 'exchangeItems'. The field
     * 'exchangeItems' has the following description: Specify the
     * list of items to exchange between the model and OpenDA
     * components. An exchange item may be defined either as vector
     * or subvector.
     * 
     * @return the value of field 'exchangeItems'.
     */
    public org.openda.core.io.castorgenerated.ExchangeItemXML getExchangeItems()
    {
        return this._exchangeItems;
    } //-- org.openda.core.io.castorgenerated.ExchangeItemXML getExchangeItems() 

    /**
     * Returns the value of field 'restartInfo'. The field
     * 'restartInfo' has the following description: Restart
     * dir./files information.
     * 
     * @return the value of field 'restartInfo'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML getRestartInfo()
    {
        return this._restartInfo;
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML getRestartInfo() 

    /**
     * Returns the value of field
     * 'skipModelActionsIfInstanceDirExists'. The field
     * 'skipModelActionsIfInstanceDirExists' has the following
     * description: If set to true, no actions are executed on a
     * model instance that already exists (boolean, optional)
     * 
     * @return the value of field
     * 'skipModelActionsIfInstanceDirExists'.
     */
    public boolean getSkipModelActionsIfInstanceDirExists()
    {
        return this._skipModelActionsIfInstanceDirExists;
    } //-- boolean getSkipModelActionsIfInstanceDirExists() 

    /**
     * Returns the value of field 'wrapperConfig'. The field
     * 'wrapperConfig' has the following description: Specify black
     * box wrapper configuration that addresses the deterministic
     * model
     * 
     * @return the value of field 'wrapperConfig'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxWrapperConfigReferenceXML getWrapperConfig()
    {
        return this._wrapperConfig;
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperConfigReferenceXML getWrapperConfig() 

    /**
     * Method hasDoCleanUp
     */
    public boolean hasDoCleanUp()
    {
        return this._has_doCleanUp;
    } //-- boolean hasDoCleanUp() 

    /**
     * Method hasSkipModelActionsIfInstanceDirExists
     */
    public boolean hasSkipModelActionsIfInstanceDirExists()
    {
        return this._has_skipModelActionsIfInstanceDirExists;
    } //-- boolean hasSkipModelActionsIfInstanceDirExists() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'aliasValues'. The field
     * 'aliasValues' has the following description: Specify the
     * actual values referred to by the alias keys defined in the
     * black box wrapper configuration
     * 
     * @param aliasValues the value of field 'aliasValues'.
     */
    public void setAliasValues(org.openda.core.io.castorgenerated.AliasValuesXML aliasValues)
    {
        this._aliasValues = aliasValues;
    } //-- void setAliasValues(org.openda.core.io.castorgenerated.AliasValuesXML) 

    /**
     * Sets the value of field 'blackBoxModelConfigXMLChoice'. The
     * field 'blackBoxModelConfigXMLChoice' has the following
     * description: Select one of the options
     * 
     * @param blackBoxModelConfigXMLChoice the value of field
     * 'blackBoxModelConfigXMLChoice'.
     */
    public void setBlackBoxModelConfigXMLChoice(org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice blackBoxModelConfigXMLChoice)
    {
        this._blackBoxModelConfigXMLChoice = blackBoxModelConfigXMLChoice;
    } //-- void setBlackBoxModelConfigXMLChoice(org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice) 

    /**
     * Sets the value of field 'doCleanUp'. The field 'doCleanUp'
     * has the following description: Specify whether to remove
     * unnecessary files upon completion of a model run (boolean,
     * optional)
     * 
     * @param doCleanUp the value of field 'doCleanUp'.
     */
    public void setDoCleanUp(boolean doCleanUp)
    {
        this._doCleanUp = doCleanUp;
        this._has_doCleanUp = true;
    } //-- void setDoCleanUp(boolean) 

    /**
     * Sets the value of field 'exchangeItems'. The field
     * 'exchangeItems' has the following description: Specify the
     * list of items to exchange between the model and OpenDA
     * components. An exchange item may be defined either as vector
     * or subvector.
     * 
     * @param exchangeItems the value of field 'exchangeItems'.
     */
    public void setExchangeItems(org.openda.core.io.castorgenerated.ExchangeItemXML exchangeItems)
    {
        this._exchangeItems = exchangeItems;
    } //-- void setExchangeItems(org.openda.core.io.castorgenerated.ExchangeItemXML) 

    /**
     * Sets the value of field 'restartInfo'. The field
     * 'restartInfo' has the following description: Restart
     * dir./files information.
     * 
     * @param restartInfo the value of field 'restartInfo'.
     */
    public void setRestartInfo(org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML restartInfo)
    {
        this._restartInfo = restartInfo;
    } //-- void setRestartInfo(org.openda.core.io.castorgenerated.BlackBoxModelRestartInfoXML) 

    /**
     * Sets the value of field
     * 'skipModelActionsIfInstanceDirExists'. The field
     * 'skipModelActionsIfInstanceDirExists' has the following
     * description: If set to true, no actions are executed on a
     * model instance that already exists (boolean, optional)
     * 
     * @param skipModelActionsIfInstanceDirExists the value of
     * field 'skipModelActionsIfInstanceDirExists'.
     */
    public void setSkipModelActionsIfInstanceDirExists(boolean skipModelActionsIfInstanceDirExists)
    {
        this._skipModelActionsIfInstanceDirExists = skipModelActionsIfInstanceDirExists;
        this._has_skipModelActionsIfInstanceDirExists = true;
    } //-- void setSkipModelActionsIfInstanceDirExists(boolean) 

    /**
     * Sets the value of field 'wrapperConfig'. The field
     * 'wrapperConfig' has the following description: Specify black
     * box wrapper configuration that addresses the deterministic
     * model
     * 
     * @param wrapperConfig the value of field 'wrapperConfig'.
     */
    public void setWrapperConfig(org.openda.core.io.castorgenerated.BlackBoxWrapperConfigReferenceXML wrapperConfig)
    {
        this._wrapperConfig = wrapperConfig;
    } //-- void setWrapperConfig(org.openda.core.io.castorgenerated.BlackBoxWrapperConfigReferenceXML) 

    /**
     * Method unmarshalBlackBoxModelConfigXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxModelConfigXML unmarshalBlackBoxModelConfigXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxModelConfigXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxModelConfigXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelConfigXML unmarshalBlackBoxModelConfigXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
