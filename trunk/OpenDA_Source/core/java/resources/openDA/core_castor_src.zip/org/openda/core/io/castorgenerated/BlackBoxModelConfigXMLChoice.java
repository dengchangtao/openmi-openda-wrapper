/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Select one of the options
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxModelConfigXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the time information of the simulation (optional)
     */
    private org.openda.core.io.castorgenerated.TimeInfoXML _timeInfo;

    /**
     * Specify the time information of the simulation in terms of
     * ioObject exchange item id's (optional). Multiple
     * timeInfoExchangeItems can be specified, each one with a
     * unique id. This is needed if there are multiple ioObjects
     * that have exchangeItems for the start and/or end time.
     */
    private java.util.ArrayList _timeInfoExchangeItemsList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxModelConfigXMLChoice() {
        super();
        _timeInfoExchangeItemsList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addTimeInfoExchangeItems
     * 
     * @param vTimeInfoExchangeItems
     */
    public void addTimeInfoExchangeItems(org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML vTimeInfoExchangeItems)
        throws java.lang.IndexOutOfBoundsException
    {
        _timeInfoExchangeItemsList.add(vTimeInfoExchangeItems);
    } //-- void addTimeInfoExchangeItems(org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) 

    /**
     * Method addTimeInfoExchangeItems
     * 
     * @param index
     * @param vTimeInfoExchangeItems
     */
    public void addTimeInfoExchangeItems(int index, org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML vTimeInfoExchangeItems)
        throws java.lang.IndexOutOfBoundsException
    {
        _timeInfoExchangeItemsList.add(index, vTimeInfoExchangeItems);
    } //-- void addTimeInfoExchangeItems(int, org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) 

    /**
     * Method clearTimeInfoExchangeItems
     */
    public void clearTimeInfoExchangeItems()
    {
        _timeInfoExchangeItemsList.clear();
    } //-- void clearTimeInfoExchangeItems() 

    /**
     * Method enumerateTimeInfoExchangeItems
     */
    public java.util.Enumeration enumerateTimeInfoExchangeItems()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_timeInfoExchangeItemsList.iterator());
    } //-- java.util.Enumeration enumerateTimeInfoExchangeItems() 

    /**
     * Returns the value of field 'timeInfo'. The field 'timeInfo'
     * has the following description: Specify the time information
     * of the simulation (optional)
     * 
     * @return the value of field 'timeInfo'.
     */
    public org.openda.core.io.castorgenerated.TimeInfoXML getTimeInfo()
    {
        return this._timeInfo;
    } //-- org.openda.core.io.castorgenerated.TimeInfoXML getTimeInfo() 

    /**
     * Method getTimeInfoExchangeItems
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML getTimeInfoExchangeItems(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _timeInfoExchangeItemsList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) _timeInfoExchangeItemsList.get(index);
    } //-- org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML getTimeInfoExchangeItems(int) 

    /**
     * Method getTimeInfoExchangeItems
     */
    public org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML[] getTimeInfoExchangeItems()
    {
        int size = _timeInfoExchangeItemsList.size();
        org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML[] mArray = new org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) _timeInfoExchangeItemsList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML[] getTimeInfoExchangeItems() 

    /**
     * Method getTimeInfoExchangeItemsCount
     */
    public int getTimeInfoExchangeItemsCount()
    {
        return _timeInfoExchangeItemsList.size();
    } //-- int getTimeInfoExchangeItemsCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeTimeInfoExchangeItems
     * 
     * @param vTimeInfoExchangeItems
     */
    public boolean removeTimeInfoExchangeItems(org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML vTimeInfoExchangeItems)
    {
        boolean removed = _timeInfoExchangeItemsList.remove(vTimeInfoExchangeItems);
        return removed;
    } //-- boolean removeTimeInfoExchangeItems(org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) 

    /**
     * Sets the value of field 'timeInfo'. The field 'timeInfo' has
     * the following description: Specify the time information of
     * the simulation (optional)
     * 
     * @param timeInfo the value of field 'timeInfo'.
     */
    public void setTimeInfo(org.openda.core.io.castorgenerated.TimeInfoXML timeInfo)
    {
        this._timeInfo = timeInfo;
    } //-- void setTimeInfo(org.openda.core.io.castorgenerated.TimeInfoXML) 

    /**
     * Method setTimeInfoExchangeItems
     * 
     * @param index
     * @param vTimeInfoExchangeItems
     */
    public void setTimeInfoExchangeItems(int index, org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML vTimeInfoExchangeItems)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _timeInfoExchangeItemsList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _timeInfoExchangeItemsList.set(index, vTimeInfoExchangeItems);
    } //-- void setTimeInfoExchangeItems(int, org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) 

    /**
     * Method setTimeInfoExchangeItems
     * 
     * @param timeInfoExchangeItemsArray
     */
    public void setTimeInfoExchangeItems(org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML[] timeInfoExchangeItemsArray)
    {
        //-- copy array
        _timeInfoExchangeItemsList.clear();
        for (int i = 0; i < timeInfoExchangeItemsArray.length; i++) {
            _timeInfoExchangeItemsList.add(timeInfoExchangeItemsArray[i]);
        }
    } //-- void setTimeInfoExchangeItems(org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) 

    /**
     * Method unmarshalBlackBoxModelConfigXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice unmarshalBlackBoxModelConfigXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxModelConfigXMLChoice unmarshalBlackBoxModelConfigXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
