/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class BlackBoxStochModelParametersXMLItem.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelParametersXMLItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The uncertainty module that defines and generates the noise
     * correction factor exchange items 
     */
    private org.openda.core.io.castorgenerated.UncertaintyOrNoiseXML _uncertaintyModule;

    /**
     * Specify which model parameters to adjust and how
     */
    private org.openda.core.io.castorgenerated.RegularisationConstantXML _regularisationConstant;

    /**
     * Specify which model parameters to adjust and how, under a
     * transformation of the vector representation, from Cartesian
     * (dx,dy) to Polar (amplitude,phase)
     */
    private org.openda.core.io.castorgenerated.CartesianToPolarXML _cartesianToPolar;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelParametersXMLItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelParametersXMLItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'cartesianToPolar'. The field
     * 'cartesianToPolar' has the following description: Specify
     * which model parameters to adjust and how, under a
     * transformation of the vector representation, from Cartesian
     * (dx,dy) to Polar (amplitude,phase)
     * 
     * @return the value of field 'cartesianToPolar'.
     */
    public org.openda.core.io.castorgenerated.CartesianToPolarXML getCartesianToPolar()
    {
        return this._cartesianToPolar;
    } //-- org.openda.core.io.castorgenerated.CartesianToPolarXML getCartesianToPolar() 

    /**
     * Returns the value of field 'regularisationConstant'. The
     * field 'regularisationConstant' has the following
     * description: Specify which model parameters to adjust and
     * how
     * 
     * @return the value of field 'regularisationConstant'.
     */
    public org.openda.core.io.castorgenerated.RegularisationConstantXML getRegularisationConstant()
    {
        return this._regularisationConstant;
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXML getRegularisationConstant() 

    /**
     * Returns the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: The
     * uncertainty module that defines and generates the noise
     * correction factor exchange items 
     * 
     * @return the value of field 'uncertaintyModule'.
     */
    public org.openda.core.io.castorgenerated.UncertaintyOrNoiseXML getUncertaintyModule()
    {
        return this._uncertaintyModule;
    } //-- org.openda.core.io.castorgenerated.UncertaintyOrNoiseXML getUncertaintyModule() 

    /**
     * Sets the value of field 'cartesianToPolar'. The field
     * 'cartesianToPolar' has the following description: Specify
     * which model parameters to adjust and how, under a
     * transformation of the vector representation, from Cartesian
     * (dx,dy) to Polar (amplitude,phase)
     * 
     * @param cartesianToPolar the value of field 'cartesianToPolar'
     */
    public void setCartesianToPolar(org.openda.core.io.castorgenerated.CartesianToPolarXML cartesianToPolar)
    {
        this._cartesianToPolar = cartesianToPolar;
    } //-- void setCartesianToPolar(org.openda.core.io.castorgenerated.CartesianToPolarXML) 

    /**
     * Sets the value of field 'regularisationConstant'. The field
     * 'regularisationConstant' has the following description:
     * Specify which model parameters to adjust and how
     * 
     * @param regularisationConstant the value of field
     * 'regularisationConstant'.
     */
    public void setRegularisationConstant(org.openda.core.io.castorgenerated.RegularisationConstantXML regularisationConstant)
    {
        this._regularisationConstant = regularisationConstant;
    } //-- void setRegularisationConstant(org.openda.core.io.castorgenerated.RegularisationConstantXML) 

    /**
     * Sets the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: The
     * uncertainty module that defines and generates the noise
     * correction factor exchange items 
     * 
     * @param uncertaintyModule the value of field
     * 'uncertaintyModule'.
     */
    public void setUncertaintyModule(org.openda.core.io.castorgenerated.UncertaintyOrNoiseXML uncertaintyModule)
    {
        this._uncertaintyModule = uncertaintyModule;
    } //-- void setUncertaintyModule(org.openda.core.io.castorgenerated.UncertaintyOrNoiseXML) 

}
