/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TimeInfoExchangeItemsXML.
 * 
 * @version $Revision$ $Date$
 */
public class TimeInfoExchangeItemsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The identifier of the exchange item that contains the start
     * time of the simulation
     */
    private java.lang.String _start;

    /**
     * The identifier of the exchange item that contains the end
     * time of the simulation
     */
    private java.lang.String _end;


      //----------------/
     //- Constructors -/
    //----------------/

    public TimeInfoExchangeItemsXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'end'. The field 'end' has the
     * following description: The identifier of the exchange item
     * that contains the end time of the simulation
     * 
     * @return the value of field 'end'.
     */
    public java.lang.String getEnd()
    {
        return this._end;
    } //-- java.lang.String getEnd() 

    /**
     * Returns the value of field 'start'. The field 'start' has
     * the following description: The identifier of the exchange
     * item that contains the start time of the simulation
     * 
     * @return the value of field 'start'.
     */
    public java.lang.String getStart()
    {
        return this._start;
    } //-- java.lang.String getStart() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'end'. The field 'end' has the
     * following description: The identifier of the exchange item
     * that contains the end time of the simulation
     * 
     * @param end the value of field 'end'.
     */
    public void setEnd(java.lang.String end)
    {
        this._end = end;
    } //-- void setEnd(java.lang.String) 

    /**
     * Sets the value of field 'start'. The field 'start' has the
     * following description: The identifier of the exchange item
     * that contains the start time of the simulation
     * 
     * @param start the value of field 'start'.
     */
    public void setStart(java.lang.String start)
    {
        this._start = start;
    } //-- void setStart(java.lang.String) 

    /**
     * Method unmarshalTimeInfoExchangeItemsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML unmarshalTimeInfoExchangeItemsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TimeInfoExchangeItemsXML unmarshalTimeInfoExchangeItemsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
