/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxIoSubVectorXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxIoSubVectorXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Identity of the exchange item vector to be used in the
     * stochastic model configuration
     */
    private java.lang.String _id;

    /**
     * The corresponding object identity of the exchange item
     */
    private java.lang.String _ioObjectId;

    /**
     * The corresponding identity of the exchange item as used
     * internally within the model
     */
    private java.lang.String _elementId;

    /**
     * The corresponding role type of the exchange item, choose
     * "Input", "Output" or "InOut"
     */
    private org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML _role = org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML.valueOf("InOut");

    /**
     * Select subvector using indices of the vector elements
     */
    private org.openda.core.io.castorgenerated.IndicesXML _selection;

    /**
     * Define operator for deriving the subvector
     */
    private org.openda.core.io.castorgenerated.BlackBoxConfigurableXML _selector;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxIoSubVectorXML() {
        super();
        setRole(org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML.valueOf("InOut"));
    } //-- org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'elementId'. The field
     * 'elementId' has the following description: The corresponding
     * identity of the exchange item as used internally within the
     * model
     * 
     * @return the value of field 'elementId'.
     */
    public java.lang.String getElementId()
    {
        return this._elementId;
    } //-- java.lang.String getElementId() 

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Identity of the exchange item vector
     * to be used in the stochastic model configuration
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'ioObjectId'. The field
     * 'ioObjectId' has the following description: The
     * corresponding object identity of the exchange item
     * 
     * @return the value of field 'ioObjectId'.
     */
    public java.lang.String getIoObjectId()
    {
        return this._ioObjectId;
    } //-- java.lang.String getIoObjectId() 

    /**
     * Returns the value of field 'role'. The field 'role' has the
     * following description: The corresponding role type of the
     * exchange item, choose "Input", "Output" or "InOut"
     * 
     * @return the value of field 'role'.
     */
    public org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML getRole()
    {
        return this._role;
    } //-- org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML getRole() 

    /**
     * Returns the value of field 'selection'. The field
     * 'selection' has the following description: Select subvector
     * using indices of the vector elements
     * 
     * @return the value of field 'selection'.
     */
    public org.openda.core.io.castorgenerated.IndicesXML getSelection()
    {
        return this._selection;
    } //-- org.openda.core.io.castorgenerated.IndicesXML getSelection() 

    /**
     * Returns the value of field 'selector'. The field 'selector'
     * has the following description: Define operator for deriving
     * the subvector
     * 
     * @return the value of field 'selector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxConfigurableXML getSelector()
    {
        return this._selector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxConfigurableXML getSelector() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'elementId'. The field 'elementId'
     * has the following description: The corresponding identity of
     * the exchange item as used internally within the model
     * 
     * @param elementId the value of field 'elementId'.
     */
    public void setElementId(java.lang.String elementId)
    {
        this._elementId = elementId;
    } //-- void setElementId(java.lang.String) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Identity of the exchange item vector
     * to be used in the stochastic model configuration
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'ioObjectId'. The field 'ioObjectId'
     * has the following description: The corresponding object
     * identity of the exchange item
     * 
     * @param ioObjectId the value of field 'ioObjectId'.
     */
    public void setIoObjectId(java.lang.String ioObjectId)
    {
        this._ioObjectId = ioObjectId;
    } //-- void setIoObjectId(java.lang.String) 

    /**
     * Sets the value of field 'role'. The field 'role' has the
     * following description: The corresponding role type of the
     * exchange item, choose "Input", "Output" or "InOut"
     * 
     * @param role the value of field 'role'.
     */
    public void setRole(org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML role)
    {
        this._role = role;
    } //-- void setRole(org.openda.core.io.castorgenerated.types.BlackBoxModelRoleTypesXML) 

    /**
     * Sets the value of field 'selection'. The field 'selection'
     * has the following description: Select subvector using
     * indices of the vector elements
     * 
     * @param selection the value of field 'selection'.
     */
    public void setSelection(org.openda.core.io.castorgenerated.IndicesXML selection)
    {
        this._selection = selection;
    } //-- void setSelection(org.openda.core.io.castorgenerated.IndicesXML) 

    /**
     * Sets the value of field 'selector'. The field 'selector' has
     * the following description: Define operator for deriving the
     * subvector
     * 
     * @param selector the value of field 'selector'.
     */
    public void setSelector(org.openda.core.io.castorgenerated.BlackBoxConfigurableXML selector)
    {
        this._selector = selector;
    } //-- void setSelector(org.openda.core.io.castorgenerated.BlackBoxConfigurableXML) 

    /**
     * Method unmarshalBlackBoxIoSubVectorXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML unmarshalBlackBoxIoSubVectorXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML unmarshalBlackBoxIoSubVectorXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
