/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Configure method for model initialization. Select one of the
 * three options.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxWrapperRunXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Generic method of initialization actions
     */
    private org.openda.core.io.castorgenerated.ActionsXML _initializeActions;

    /**
     * The directory, in which the model executables and input
     * files are located, will be copied to a new working
     * directory. The actions are executed in this new working
     * directory.
     */
    private org.openda.core.io.castorgenerated.InitialActionsDirCloneXML _initializeActionsUsingDirClone;

    /**
     * Some of the model files (template) will be copied to the
     * working directory where the actions will be executed
     */
    private org.openda.core.io.castorgenerated.InitialActionsFileCloneXML _initializeActionsUsingFileClone;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxWrapperRunXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'initializeActions'. The field
     * 'initializeActions' has the following description: Generic
     * method of initialization actions
     * 
     * @return the value of field 'initializeActions'.
     */
    public org.openda.core.io.castorgenerated.ActionsXML getInitializeActions()
    {
        return this._initializeActions;
    } //-- org.openda.core.io.castorgenerated.ActionsXML getInitializeActions() 

    /**
     * Returns the value of field 'initializeActionsUsingDirClone'.
     * The field 'initializeActionsUsingDirClone' has the following
     * description: The directory, in which the model executables
     * and input files are located, will be copied to a new working
     * directory. The actions are executed in this new working
     * directory.
     * 
     * @return the value of field 'initializeActionsUsingDirClone'.
     */
    public org.openda.core.io.castorgenerated.InitialActionsDirCloneXML getInitializeActionsUsingDirClone()
    {
        return this._initializeActionsUsingDirClone;
    } //-- org.openda.core.io.castorgenerated.InitialActionsDirCloneXML getInitializeActionsUsingDirClone() 

    /**
     * Returns the value of field
     * 'initializeActionsUsingFileClone'. The field
     * 'initializeActionsUsingFileClone' has the following
     * description: Some of the model files (template) will be
     * copied to the working directory where the actions will be
     * executed
     * 
     * @return the value of field 'initializeActionsUsingFileClone'.
     */
    public org.openda.core.io.castorgenerated.InitialActionsFileCloneXML getInitializeActionsUsingFileClone()
    {
        return this._initializeActionsUsingFileClone;
    } //-- org.openda.core.io.castorgenerated.InitialActionsFileCloneXML getInitializeActionsUsingFileClone() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'initializeActions'. The field
     * 'initializeActions' has the following description: Generic
     * method of initialization actions
     * 
     * @param initializeActions the value of field
     * 'initializeActions'.
     */
    public void setInitializeActions(org.openda.core.io.castorgenerated.ActionsXML initializeActions)
    {
        this._initializeActions = initializeActions;
    } //-- void setInitializeActions(org.openda.core.io.castorgenerated.ActionsXML) 

    /**
     * Sets the value of field 'initializeActionsUsingDirClone'.
     * The field 'initializeActionsUsingDirClone' has the following
     * description: The directory, in which the model executables
     * and input files are located, will be copied to a new working
     * directory. The actions are executed in this new working
     * directory.
     * 
     * @param initializeActionsUsingDirClone the value of field
     * 'initializeActionsUsingDirClone'.
     */
    public void setInitializeActionsUsingDirClone(org.openda.core.io.castorgenerated.InitialActionsDirCloneXML initializeActionsUsingDirClone)
    {
        this._initializeActionsUsingDirClone = initializeActionsUsingDirClone;
    } //-- void setInitializeActionsUsingDirClone(org.openda.core.io.castorgenerated.InitialActionsDirCloneXML) 

    /**
     * Sets the value of field 'initializeActionsUsingFileClone'.
     * The field 'initializeActionsUsingFileClone' has the
     * following description: Some of the model files (template)
     * will be copied to the working directory where the actions
     * will be executed
     * 
     * @param initializeActionsUsingFileClone the value of field
     * 'initializeActionsUsingFileClone'.
     */
    public void setInitializeActionsUsingFileClone(org.openda.core.io.castorgenerated.InitialActionsFileCloneXML initializeActionsUsingFileClone)
    {
        this._initializeActionsUsingFileClone = initializeActionsUsingFileClone;
    } //-- void setInitializeActionsUsingFileClone(org.openda.core.io.castorgenerated.InitialActionsFileCloneXML) 

    /**
     * Method unmarshalBlackBoxWrapperRunXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice unmarshalBlackBoxWrapperRunXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxWrapperRunXMLChoice unmarshalBlackBoxWrapperRunXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
