/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TreeVectorLeafXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class TreeVectorLeafXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _dimensions
     */
    private org.openda.core.io.castorgenerated.DimensionsXML _dimensions;

    /**
     * Field _grid
     */
    private org.openda.core.io.castorgenerated.GridXML _grid;


      //----------------/
     //- Constructors -/
    //----------------/

    public TreeVectorLeafXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'dimensions'.
     * 
     * @return the value of field 'dimensions'.
     */
    public org.openda.core.io.castorgenerated.DimensionsXML getDimensions()
    {
        return this._dimensions;
    } //-- org.openda.core.io.castorgenerated.DimensionsXML getDimensions() 

    /**
     * Returns the value of field 'grid'.
     * 
     * @return the value of field 'grid'.
     */
    public org.openda.core.io.castorgenerated.GridXML getGrid()
    {
        return this._grid;
    } //-- org.openda.core.io.castorgenerated.GridXML getGrid() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'dimensions'.
     * 
     * @param dimensions the value of field 'dimensions'.
     */
    public void setDimensions(org.openda.core.io.castorgenerated.DimensionsXML dimensions)
    {
        this._dimensions = dimensions;
    } //-- void setDimensions(org.openda.core.io.castorgenerated.DimensionsXML) 

    /**
     * Sets the value of field 'grid'.
     * 
     * @param grid the value of field 'grid'.
     */
    public void setGrid(org.openda.core.io.castorgenerated.GridXML grid)
    {
        this._grid = grid;
    } //-- void setGrid(org.openda.core.io.castorgenerated.GridXML) 

    /**
     * Method unmarshalTreeVectorLeafXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice unmarshalTreeVectorLeafXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.TreeVectorLeafXMLChoice unmarshalTreeVectorLeafXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
