/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ResultSelectionXML.
 * 
 * @version $Revision$ $Date$
 */
public class ResultSelectionXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Switch sources on or off for output
     */
    private org.openda.core.io.castorgenerated.ResultLoggingXML _doLog;

    /**
     * Select the items to be switched on/off for output
     */
    private java.util.ArrayList _resultItemList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ResultSelectionXML() {
        super();
        _resultItemList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.ResultSelectionXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addResultItem
     * 
     * @param vResultItem
     */
    public void addResultItem(org.openda.core.io.castorgenerated.ResultItemXML vResultItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _resultItemList.add(vResultItem);
    } //-- void addResultItem(org.openda.core.io.castorgenerated.ResultItemXML) 

    /**
     * Method addResultItem
     * 
     * @param index
     * @param vResultItem
     */
    public void addResultItem(int index, org.openda.core.io.castorgenerated.ResultItemXML vResultItem)
        throws java.lang.IndexOutOfBoundsException
    {
        _resultItemList.add(index, vResultItem);
    } //-- void addResultItem(int, org.openda.core.io.castorgenerated.ResultItemXML) 

    /**
     * Method clearResultItem
     */
    public void clearResultItem()
    {
        _resultItemList.clear();
    } //-- void clearResultItem() 

    /**
     * Method enumerateResultItem
     */
    public java.util.Enumeration enumerateResultItem()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_resultItemList.iterator());
    } //-- java.util.Enumeration enumerateResultItem() 

    /**
     * Returns the value of field 'doLog'. The field 'doLog' has
     * the following description: Switch sources on or off for
     * output
     * 
     * @return the value of field 'doLog'.
     */
    public org.openda.core.io.castorgenerated.ResultLoggingXML getDoLog()
    {
        return this._doLog;
    } //-- org.openda.core.io.castorgenerated.ResultLoggingXML getDoLog() 

    /**
     * Method getResultItem
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.ResultItemXML getResultItem(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _resultItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.ResultItemXML) _resultItemList.get(index);
    } //-- org.openda.core.io.castorgenerated.ResultItemXML getResultItem(int) 

    /**
     * Method getResultItem
     */
    public org.openda.core.io.castorgenerated.ResultItemXML[] getResultItem()
    {
        int size = _resultItemList.size();
        org.openda.core.io.castorgenerated.ResultItemXML[] mArray = new org.openda.core.io.castorgenerated.ResultItemXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.ResultItemXML) _resultItemList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.ResultItemXML[] getResultItem() 

    /**
     * Method getResultItemCount
     */
    public int getResultItemCount()
    {
        return _resultItemList.size();
    } //-- int getResultItemCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeResultItem
     * 
     * @param vResultItem
     */
    public boolean removeResultItem(org.openda.core.io.castorgenerated.ResultItemXML vResultItem)
    {
        boolean removed = _resultItemList.remove(vResultItem);
        return removed;
    } //-- boolean removeResultItem(org.openda.core.io.castorgenerated.ResultItemXML) 

    /**
     * Sets the value of field 'doLog'. The field 'doLog' has the
     * following description: Switch sources on or off for output
     * 
     * @param doLog the value of field 'doLog'.
     */
    public void setDoLog(org.openda.core.io.castorgenerated.ResultLoggingXML doLog)
    {
        this._doLog = doLog;
    } //-- void setDoLog(org.openda.core.io.castorgenerated.ResultLoggingXML) 

    /**
     * Method setResultItem
     * 
     * @param index
     * @param vResultItem
     */
    public void setResultItem(int index, org.openda.core.io.castorgenerated.ResultItemXML vResultItem)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _resultItemList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _resultItemList.set(index, vResultItem);
    } //-- void setResultItem(int, org.openda.core.io.castorgenerated.ResultItemXML) 

    /**
     * Method setResultItem
     * 
     * @param resultItemArray
     */
    public void setResultItem(org.openda.core.io.castorgenerated.ResultItemXML[] resultItemArray)
    {
        //-- copy array
        _resultItemList.clear();
        for (int i = 0; i < resultItemArray.length; i++) {
            _resultItemList.add(resultItemArray[i]);
        }
    } //-- void setResultItem(org.openda.core.io.castorgenerated.ResultItemXML) 

    /**
     * Method unmarshalResultSelectionXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ResultSelectionXML unmarshalResultSelectionXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ResultSelectionXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ResultSelectionXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ResultSelectionXML unmarshalResultSelectionXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
