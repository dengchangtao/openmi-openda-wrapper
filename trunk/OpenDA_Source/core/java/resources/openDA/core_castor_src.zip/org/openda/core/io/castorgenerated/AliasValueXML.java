/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class AliasValueXML.
 * 
 * @version $Revision$ $Date$
 */
public class AliasValueXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The alias key name as defined in the black box wrapper
     * configuration
     */
    private java.lang.String _key;

    /**
     * The actual value referred to by the alias key
     */
    private java.lang.String _value;

    /**
     * This type of alias can only be used for BBAction arguments,
     * where the argument must be specified by means of only naming
     * the 'list value' alias. If the listValue element is present,
     * it overrules the value attribute, indicating that the actual
     * value is in fact a list of string arguments instead of one
     * argument.
     */
    private java.util.ArrayList _listValueList;


      //----------------/
     //- Constructors -/
    //----------------/

    public AliasValueXML() {
        super();
        _listValueList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.AliasValueXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addListValue
     * 
     * @param vListValue
     */
    public void addListValue(java.lang.String vListValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _listValueList.add(vListValue);
    } //-- void addListValue(java.lang.String) 

    /**
     * Method addListValue
     * 
     * @param index
     * @param vListValue
     */
    public void addListValue(int index, java.lang.String vListValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _listValueList.add(index, vListValue);
    } //-- void addListValue(int, java.lang.String) 

    /**
     * Method clearListValue
     */
    public void clearListValue()
    {
        _listValueList.clear();
    } //-- void clearListValue() 

    /**
     * Method enumerateListValue
     */
    public java.util.Enumeration enumerateListValue()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_listValueList.iterator());
    } //-- java.util.Enumeration enumerateListValue() 

    /**
     * Returns the value of field 'key'. The field 'key' has the
     * following description: The alias key name as defined in the
     * black box wrapper configuration
     * 
     * @return the value of field 'key'.
     */
    public java.lang.String getKey()
    {
        return this._key;
    } //-- java.lang.String getKey() 

    /**
     * Method getListValue
     * 
     * @param index
     */
    public java.lang.String getListValue(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _listValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (String)_listValueList.get(index);
    } //-- java.lang.String getListValue(int) 

    /**
     * Method getListValue
     */
    public java.lang.String[] getListValue()
    {
        int size = _listValueList.size();
        java.lang.String[] mArray = new java.lang.String[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (String)_listValueList.get(index);
        }
        return mArray;
    } //-- java.lang.String[] getListValue() 

    /**
     * Method getListValueCount
     */
    public int getListValueCount()
    {
        return _listValueList.size();
    } //-- int getListValueCount() 

    /**
     * Returns the value of field 'value'. The field 'value' has
     * the following description: The actual value referred to by
     * the alias key
     * 
     * @return the value of field 'value'.
     */
    public java.lang.String getValue()
    {
        return this._value;
    } //-- java.lang.String getValue() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeListValue
     * 
     * @param vListValue
     */
    public boolean removeListValue(java.lang.String vListValue)
    {
        boolean removed = _listValueList.remove(vListValue);
        return removed;
    } //-- boolean removeListValue(java.lang.String) 

    /**
     * Sets the value of field 'key'. The field 'key' has the
     * following description: The alias key name as defined in the
     * black box wrapper configuration
     * 
     * @param key the value of field 'key'.
     */
    public void setKey(java.lang.String key)
    {
        this._key = key;
    } //-- void setKey(java.lang.String) 

    /**
     * Method setListValue
     * 
     * @param index
     * @param vListValue
     */
    public void setListValue(int index, java.lang.String vListValue)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _listValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _listValueList.set(index, vListValue);
    } //-- void setListValue(int, java.lang.String) 

    /**
     * Method setListValue
     * 
     * @param listValueArray
     */
    public void setListValue(java.lang.String[] listValueArray)
    {
        //-- copy array
        _listValueList.clear();
        for (int i = 0; i < listValueArray.length; i++) {
            _listValueList.add(listValueArray[i]);
        }
    } //-- void setListValue(java.lang.String) 

    /**
     * Sets the value of field 'value'. The field 'value' has the
     * following description: The actual value referred to by the
     * alias key
     * 
     * @param value the value of field 'value'.
     */
    public void setValue(java.lang.String value)
    {
        this._value = value;
    } //-- void setValue(java.lang.String) 

    /**
     * Method unmarshalAliasValueXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.AliasValueXML unmarshalAliasValueXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.AliasValueXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.AliasValueXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.AliasValueXML unmarshalAliasValueXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
