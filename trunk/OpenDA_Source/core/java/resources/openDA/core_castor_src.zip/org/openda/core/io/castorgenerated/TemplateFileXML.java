/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TemplateFileXML.
 * 
 * @version $Revision$ $Date$
 */
public class TemplateFileXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Name of the template file.
     */
    private java.lang.String _templateFile;

    /**
     * Name of the target file.
     */
    private java.lang.String _targetFile;

    /**
     * Specify list of keys to be replaced in the templateFile.
     */
    private org.openda.core.io.castorgenerated.TemplateFileKeysXML _keys;


      //----------------/
     //- Constructors -/
    //----------------/

    public TemplateFileXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.TemplateFileXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'keys'. The field 'keys' has the
     * following description: Specify list of keys to be replaced
     * in the templateFile.
     * 
     * @return the value of field 'keys'.
     */
    public org.openda.core.io.castorgenerated.TemplateFileKeysXML getKeys()
    {
        return this._keys;
    } //-- org.openda.core.io.castorgenerated.TemplateFileKeysXML getKeys() 

    /**
     * Returns the value of field 'targetFile'. The field
     * 'targetFile' has the following description: Name of the
     * target file.
     * 
     * @return the value of field 'targetFile'.
     */
    public java.lang.String getTargetFile()
    {
        return this._targetFile;
    } //-- java.lang.String getTargetFile() 

    /**
     * Returns the value of field 'templateFile'. The field
     * 'templateFile' has the following description: Name of the
     * template file.
     * 
     * @return the value of field 'templateFile'.
     */
    public java.lang.String getTemplateFile()
    {
        return this._templateFile;
    } //-- java.lang.String getTemplateFile() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'keys'. The field 'keys' has the
     * following description: Specify list of keys to be replaced
     * in the templateFile.
     * 
     * @param keys the value of field 'keys'.
     */
    public void setKeys(org.openda.core.io.castorgenerated.TemplateFileKeysXML keys)
    {
        this._keys = keys;
    } //-- void setKeys(org.openda.core.io.castorgenerated.TemplateFileKeysXML) 

    /**
     * Sets the value of field 'targetFile'. The field 'targetFile'
     * has the following description: Name of the target file.
     * 
     * @param targetFile the value of field 'targetFile'.
     */
    public void setTargetFile(java.lang.String targetFile)
    {
        this._targetFile = targetFile;
    } //-- void setTargetFile(java.lang.String) 

    /**
     * Sets the value of field 'templateFile'. The field
     * 'templateFile' has the following description: Name of the
     * template file.
     * 
     * @param templateFile the value of field 'templateFile'.
     */
    public void setTemplateFile(java.lang.String templateFile)
    {
        this._templateFile = templateFile;
    } //-- void setTemplateFile(java.lang.String) 

    /**
     * Method unmarshalTemplateFileXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TemplateFileXML unmarshalTemplateFileXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TemplateFileXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TemplateFileXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TemplateFileXML unmarshalTemplateFileXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
