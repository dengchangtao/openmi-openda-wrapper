/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class ApplicationOptimizationXML.
 * 
 * @version $Revision$ $Date$
 */
public class ApplicationOptimizationXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Optimize for performance at cost of (diagnostic) output
     */
    private boolean _productionRun;

    /**
     * keeps track of state for field: _productionRun
     */
    private boolean _has_productionRun;

    /**
     * The storage and computation precision of the default OpenDA
     * Vector class is float. Note this will not hava any impact on
     * other (native) vector implementations used in OpenDA
     */
    private boolean _vectorPrecisionIsFloat;

    /**
     * keeps track of state for field: _vectorPrecisionIsFloat
     */
    private boolean _has_vectorPrecisionIsFloat;


      //----------------/
     //- Constructors -/
    //----------------/

    public ApplicationOptimizationXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.ApplicationOptimizationXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'productionRun'. The field
     * 'productionRun' has the following description: Optimize for
     * performance at cost of (diagnostic) output
     * 
     * @return the value of field 'productionRun'.
     */
    public boolean getProductionRun()
    {
        return this._productionRun;
    } //-- boolean getProductionRun() 

    /**
     * Returns the value of field 'vectorPrecisionIsFloat'. The
     * field 'vectorPrecisionIsFloat' has the following
     * description: The storage and computation precision of the
     * default OpenDA Vector class is float. Note this will not
     * hava any impact on other (native) vector implementations
     * used in OpenDA
     * 
     * @return the value of field 'vectorPrecisionIsFloat'.
     */
    public boolean getVectorPrecisionIsFloat()
    {
        return this._vectorPrecisionIsFloat;
    } //-- boolean getVectorPrecisionIsFloat() 

    /**
     * Method hasProductionRun
     */
    public boolean hasProductionRun()
    {
        return this._has_productionRun;
    } //-- boolean hasProductionRun() 

    /**
     * Method hasVectorPrecisionIsFloat
     */
    public boolean hasVectorPrecisionIsFloat()
    {
        return this._has_vectorPrecisionIsFloat;
    } //-- boolean hasVectorPrecisionIsFloat() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'productionRun'. The field
     * 'productionRun' has the following description: Optimize for
     * performance at cost of (diagnostic) output
     * 
     * @param productionRun the value of field 'productionRun'.
     */
    public void setProductionRun(boolean productionRun)
    {
        this._productionRun = productionRun;
        this._has_productionRun = true;
    } //-- void setProductionRun(boolean) 

    /**
     * Sets the value of field 'vectorPrecisionIsFloat'. The field
     * 'vectorPrecisionIsFloat' has the following description: The
     * storage and computation precision of the default OpenDA
     * Vector class is float. Note this will not hava any impact on
     * other (native) vector implementations used in OpenDA
     * 
     * @param vectorPrecisionIsFloat the value of field
     * 'vectorPrecisionIsFloat'.
     */
    public void setVectorPrecisionIsFloat(boolean vectorPrecisionIsFloat)
    {
        this._vectorPrecisionIsFloat = vectorPrecisionIsFloat;
        this._has_vectorPrecisionIsFloat = true;
    } //-- void setVectorPrecisionIsFloat(boolean) 

    /**
     * Method unmarshalApplicationOptimizationXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ApplicationOptimizationXML unmarshalApplicationOptimizationXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ApplicationOptimizationXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ApplicationOptimizationXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ApplicationOptimizationXML unmarshalApplicationOptimizationXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
