/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxStochModelUncertainParameterXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxStochModelUncertainParameterXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Identity of model's exchange item
     */
    private java.lang.String _id;

    /**
     * Identity of noise model's exchange item
     */
    private java.lang.String _uncertainItemId;

    /**
     * Transformation of noise variable. 'identity' means that the
     * value will be added directly without any transformation to
     * the adjusted parameter. 'ln' means that the value is
     * transformed logarithmically before it is added to the
     * parameter; this gives a correction, which is a fraction of
     * the parameter value.
     */
    private org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML _transformation = org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML.valueOf("identity");


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxStochModelUncertainParameterXML() {
        super();
        setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML.valueOf("identity"));
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Identity of model's exchange item
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'transformation'. The field
     * 'transformation' has the following description:
     * Transformation of noise variable. 'identity' means that the
     * value will be added directly without any transformation to
     * the adjusted parameter. 'ln' means that the value is
     * transformed logarithmically before it is added to the
     * parameter; this gives a correction, which is a fraction of
     * the parameter value.
     * 
     * @return the value of field 'transformation'.
     */
    public org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML getTransformation()
    {
        return this._transformation;
    } //-- org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML getTransformation() 

    /**
     * Returns the value of field 'uncertainItemId'. The field
     * 'uncertainItemId' has the following description: Identity of
     * noise model's exchange item
     * 
     * @return the value of field 'uncertainItemId'.
     */
    public java.lang.String getUncertainItemId()
    {
        return this._uncertainItemId;
    } //-- java.lang.String getUncertainItemId() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Identity of model's exchange item
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'transformation'. The field
     * 'transformation' has the following description:
     * Transformation of noise variable. 'identity' means that the
     * value will be added directly without any transformation to
     * the adjusted parameter. 'ln' means that the value is
     * transformed logarithmically before it is added to the
     * parameter; this gives a correction, which is a fraction of
     * the parameter value.
     * 
     * @param transformation the value of field 'transformation'.
     */
    public void setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML transformation)
    {
        this._transformation = transformation;
    } //-- void setTransformation(org.openda.core.io.castorgenerated.types.ParameterTransformationTypesXML) 

    /**
     * Sets the value of field 'uncertainItemId'. The field
     * 'uncertainItemId' has the following description: Identity of
     * noise model's exchange item
     * 
     * @param uncertainItemId the value of field 'uncertainItemId'.
     */
    public void setUncertainItemId(java.lang.String uncertainItemId)
    {
        this._uncertainItemId = uncertainItemId;
    } //-- void setUncertainItemId(java.lang.String) 

    /**
     * Method unmarshalBlackBoxStochModelUncertainParameterXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML unmarshalBlackBoxStochModelUncertainParameterXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML unmarshalBlackBoxStochModelUncertainParameterXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
