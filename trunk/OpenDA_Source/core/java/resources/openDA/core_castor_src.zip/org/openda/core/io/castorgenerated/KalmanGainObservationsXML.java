/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class KalmanGainObservationsXML.
 * 
 * @version $Revision$ $Date$
 */
public class KalmanGainObservationsXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _observationList
     */
    private java.util.ArrayList _observationList;


      //----------------/
     //- Constructors -/
    //----------------/

    public KalmanGainObservationsXML() {
        super();
        _observationList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationsXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addObservation
     * 
     * @param vObservation
     */
    public void addObservation(org.openda.core.io.castorgenerated.KalmanGainObservationXML vObservation)
        throws java.lang.IndexOutOfBoundsException
    {
        _observationList.add(vObservation);
    } //-- void addObservation(org.openda.core.io.castorgenerated.KalmanGainObservationXML) 

    /**
     * Method addObservation
     * 
     * @param index
     * @param vObservation
     */
    public void addObservation(int index, org.openda.core.io.castorgenerated.KalmanGainObservationXML vObservation)
        throws java.lang.IndexOutOfBoundsException
    {
        _observationList.add(index, vObservation);
    } //-- void addObservation(int, org.openda.core.io.castorgenerated.KalmanGainObservationXML) 

    /**
     * Method clearObservation
     */
    public void clearObservation()
    {
        _observationList.clear();
    } //-- void clearObservation() 

    /**
     * Method enumerateObservation
     */
    public java.util.Enumeration enumerateObservation()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_observationList.iterator());
    } //-- java.util.Enumeration enumerateObservation() 

    /**
     * Method getObservation
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.KalmanGainObservationXML getObservation(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _observationList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.KalmanGainObservationXML) _observationList.get(index);
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationXML getObservation(int) 

    /**
     * Method getObservation
     */
    public org.openda.core.io.castorgenerated.KalmanGainObservationXML[] getObservation()
    {
        int size = _observationList.size();
        org.openda.core.io.castorgenerated.KalmanGainObservationXML[] mArray = new org.openda.core.io.castorgenerated.KalmanGainObservationXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.KalmanGainObservationXML) _observationList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationXML[] getObservation() 

    /**
     * Method getObservationCount
     */
    public int getObservationCount()
    {
        return _observationList.size();
    } //-- int getObservationCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeObservation
     * 
     * @param vObservation
     */
    public boolean removeObservation(org.openda.core.io.castorgenerated.KalmanGainObservationXML vObservation)
    {
        boolean removed = _observationList.remove(vObservation);
        return removed;
    } //-- boolean removeObservation(org.openda.core.io.castorgenerated.KalmanGainObservationXML) 

    /**
     * Method setObservation
     * 
     * @param index
     * @param vObservation
     */
    public void setObservation(int index, org.openda.core.io.castorgenerated.KalmanGainObservationXML vObservation)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _observationList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _observationList.set(index, vObservation);
    } //-- void setObservation(int, org.openda.core.io.castorgenerated.KalmanGainObservationXML) 

    /**
     * Method setObservation
     * 
     * @param observationArray
     */
    public void setObservation(org.openda.core.io.castorgenerated.KalmanGainObservationXML[] observationArray)
    {
        //-- copy array
        _observationList.clear();
        for (int i = 0; i < observationArray.length; i++) {
            _observationList.add(observationArray[i]);
        }
    } //-- void setObservation(org.openda.core.io.castorgenerated.KalmanGainObservationXML) 

    /**
     * Method unmarshalKalmanGainObservationsXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.KalmanGainObservationsXML unmarshalKalmanGainObservationsXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.KalmanGainObservationsXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.KalmanGainObservationsXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.KalmanGainObservationsXML unmarshalKalmanGainObservationsXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
