/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class PowellXML.
 * 
 * @version $Revision$ $Date$
 */
public class PowellXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _powellXMLChoice
     */
    private org.openda.core.io.castorgenerated.PowellXMLChoice _powellXMLChoice;

    /**
     * Field _powellXMLChoice2List
     */
    private java.util.ArrayList _powellXMLChoice2List;

    /**
     * Field _costValue
     */
    private double _costValue;

    /**
     * keeps track of state for field: _costValue
     */
    private boolean _has_costValue;


      //----------------/
     //- Constructors -/
    //----------------/

    public PowellXML() {
        super();
        _powellXMLChoice2List = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.PowellXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addPowellXMLChoice2
     * 
     * @param vPowellXMLChoice2
     */
    public void addPowellXMLChoice2(org.openda.core.io.castorgenerated.PowellXMLChoice2 vPowellXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        _powellXMLChoice2List.add(vPowellXMLChoice2);
    } //-- void addPowellXMLChoice2(org.openda.core.io.castorgenerated.PowellXMLChoice2) 

    /**
     * Method addPowellXMLChoice2
     * 
     * @param index
     * @param vPowellXMLChoice2
     */
    public void addPowellXMLChoice2(int index, org.openda.core.io.castorgenerated.PowellXMLChoice2 vPowellXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        _powellXMLChoice2List.add(index, vPowellXMLChoice2);
    } //-- void addPowellXMLChoice2(int, org.openda.core.io.castorgenerated.PowellXMLChoice2) 

    /**
     * Method clearPowellXMLChoice2
     */
    public void clearPowellXMLChoice2()
    {
        _powellXMLChoice2List.clear();
    } //-- void clearPowellXMLChoice2() 

    /**
     * Method enumeratePowellXMLChoice2
     */
    public java.util.Enumeration enumeratePowellXMLChoice2()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_powellXMLChoice2List.iterator());
    } //-- java.util.Enumeration enumeratePowellXMLChoice2() 

    /**
     * Returns the value of field 'costValue'.
     * 
     * @return the value of field 'costValue'.
     */
    public double getCostValue()
    {
        return this._costValue;
    } //-- double getCostValue() 

    /**
     * Returns the value of field 'powellXMLChoice'.
     * 
     * @return the value of field 'powellXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.PowellXMLChoice getPowellXMLChoice()
    {
        return this._powellXMLChoice;
    } //-- org.openda.core.io.castorgenerated.PowellXMLChoice getPowellXMLChoice() 

    /**
     * Method getPowellXMLChoice2
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.PowellXMLChoice2 getPowellXMLChoice2(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _powellXMLChoice2List.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.PowellXMLChoice2) _powellXMLChoice2List.get(index);
    } //-- org.openda.core.io.castorgenerated.PowellXMLChoice2 getPowellXMLChoice2(int) 

    /**
     * Method getPowellXMLChoice2
     */
    public org.openda.core.io.castorgenerated.PowellXMLChoice2[] getPowellXMLChoice2()
    {
        int size = _powellXMLChoice2List.size();
        org.openda.core.io.castorgenerated.PowellXMLChoice2[] mArray = new org.openda.core.io.castorgenerated.PowellXMLChoice2[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.PowellXMLChoice2) _powellXMLChoice2List.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.PowellXMLChoice2[] getPowellXMLChoice2() 

    /**
     * Method getPowellXMLChoice2Count
     */
    public int getPowellXMLChoice2Count()
    {
        return _powellXMLChoice2List.size();
    } //-- int getPowellXMLChoice2Count() 

    /**
     * Method hasCostValue
     */
    public boolean hasCostValue()
    {
        return this._has_costValue;
    } //-- boolean hasCostValue() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removePowellXMLChoice2
     * 
     * @param vPowellXMLChoice2
     */
    public boolean removePowellXMLChoice2(org.openda.core.io.castorgenerated.PowellXMLChoice2 vPowellXMLChoice2)
    {
        boolean removed = _powellXMLChoice2List.remove(vPowellXMLChoice2);
        return removed;
    } //-- boolean removePowellXMLChoice2(org.openda.core.io.castorgenerated.PowellXMLChoice2) 

    /**
     * Sets the value of field 'costValue'.
     * 
     * @param costValue the value of field 'costValue'.
     */
    public void setCostValue(double costValue)
    {
        this._costValue = costValue;
        this._has_costValue = true;
    } //-- void setCostValue(double) 

    /**
     * Sets the value of field 'powellXMLChoice'.
     * 
     * @param powellXMLChoice the value of field 'powellXMLChoice'.
     */
    public void setPowellXMLChoice(org.openda.core.io.castorgenerated.PowellXMLChoice powellXMLChoice)
    {
        this._powellXMLChoice = powellXMLChoice;
    } //-- void setPowellXMLChoice(org.openda.core.io.castorgenerated.PowellXMLChoice) 

    /**
     * Method setPowellXMLChoice2
     * 
     * @param index
     * @param vPowellXMLChoice2
     */
    public void setPowellXMLChoice2(int index, org.openda.core.io.castorgenerated.PowellXMLChoice2 vPowellXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _powellXMLChoice2List.size())) {
            throw new IndexOutOfBoundsException();
        }
        _powellXMLChoice2List.set(index, vPowellXMLChoice2);
    } //-- void setPowellXMLChoice2(int, org.openda.core.io.castorgenerated.PowellXMLChoice2) 

    /**
     * Method setPowellXMLChoice2
     * 
     * @param powellXMLChoice2Array
     */
    public void setPowellXMLChoice2(org.openda.core.io.castorgenerated.PowellXMLChoice2[] powellXMLChoice2Array)
    {
        //-- copy array
        _powellXMLChoice2List.clear();
        for (int i = 0; i < powellXMLChoice2Array.length; i++) {
            _powellXMLChoice2List.add(powellXMLChoice2Array[i]);
        }
    } //-- void setPowellXMLChoice2(org.openda.core.io.castorgenerated.PowellXMLChoice2) 

    /**
     * Method unmarshalPowellXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.PowellXML unmarshalPowellXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.PowellXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.PowellXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.PowellXML unmarshalPowellXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
