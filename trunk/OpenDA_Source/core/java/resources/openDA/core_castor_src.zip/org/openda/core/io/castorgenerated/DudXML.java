/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class DudXML.
 * 
 * @version $Revision$ $Date$
 */
public class DudXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _dudXMLChoiceList
     */
    private java.util.ArrayList _dudXMLChoiceList;

    /**
     * Field _costValueList
     */
    private java.util.ArrayList _costValueList;

    /**
     * Field _dudXMLChoice2List
     */
    private java.util.ArrayList _dudXMLChoice2List;


      //----------------/
     //- Constructors -/
    //----------------/

    public DudXML() {
        super();
        _dudXMLChoiceList = new ArrayList();
        _costValueList = new ArrayList();
        _dudXMLChoice2List = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.DudXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addCostValue
     * 
     * @param vCostValue
     */
    public void addCostValue(double vCostValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _costValueList.add(new Double(vCostValue));
    } //-- void addCostValue(double) 

    /**
     * Method addCostValue
     * 
     * @param index
     * @param vCostValue
     */
    public void addCostValue(int index, double vCostValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _costValueList.add(index, new Double(vCostValue));
    } //-- void addCostValue(int, double) 

    /**
     * Method addDudXMLChoice
     * 
     * @param vDudXMLChoice
     */
    public void addDudXMLChoice(org.openda.core.io.castorgenerated.DudXMLChoice vDudXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _dudXMLChoiceList.add(vDudXMLChoice);
    } //-- void addDudXMLChoice(org.openda.core.io.castorgenerated.DudXMLChoice) 

    /**
     * Method addDudXMLChoice
     * 
     * @param index
     * @param vDudXMLChoice
     */
    public void addDudXMLChoice(int index, org.openda.core.io.castorgenerated.DudXMLChoice vDudXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _dudXMLChoiceList.add(index, vDudXMLChoice);
    } //-- void addDudXMLChoice(int, org.openda.core.io.castorgenerated.DudXMLChoice) 

    /**
     * Method addDudXMLChoice2
     * 
     * @param vDudXMLChoice2
     */
    public void addDudXMLChoice2(org.openda.core.io.castorgenerated.DudXMLChoice2 vDudXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        _dudXMLChoice2List.add(vDudXMLChoice2);
    } //-- void addDudXMLChoice2(org.openda.core.io.castorgenerated.DudXMLChoice2) 

    /**
     * Method addDudXMLChoice2
     * 
     * @param index
     * @param vDudXMLChoice2
     */
    public void addDudXMLChoice2(int index, org.openda.core.io.castorgenerated.DudXMLChoice2 vDudXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        _dudXMLChoice2List.add(index, vDudXMLChoice2);
    } //-- void addDudXMLChoice2(int, org.openda.core.io.castorgenerated.DudXMLChoice2) 

    /**
     * Method clearCostValue
     */
    public void clearCostValue()
    {
        _costValueList.clear();
    } //-- void clearCostValue() 

    /**
     * Method clearDudXMLChoice
     */
    public void clearDudXMLChoice()
    {
        _dudXMLChoiceList.clear();
    } //-- void clearDudXMLChoice() 

    /**
     * Method clearDudXMLChoice2
     */
    public void clearDudXMLChoice2()
    {
        _dudXMLChoice2List.clear();
    } //-- void clearDudXMLChoice2() 

    /**
     * Method enumerateCostValue
     */
    public java.util.Enumeration enumerateCostValue()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_costValueList.iterator());
    } //-- java.util.Enumeration enumerateCostValue() 

    /**
     * Method enumerateDudXMLChoice
     */
    public java.util.Enumeration enumerateDudXMLChoice()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_dudXMLChoiceList.iterator());
    } //-- java.util.Enumeration enumerateDudXMLChoice() 

    /**
     * Method enumerateDudXMLChoice2
     */
    public java.util.Enumeration enumerateDudXMLChoice2()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_dudXMLChoice2List.iterator());
    } //-- java.util.Enumeration enumerateDudXMLChoice2() 

    /**
     * Method getCostValue
     * 
     * @param index
     */
    public double getCostValue(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _costValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return ((Double)_costValueList.get(index)).doubleValue();
    } //-- double getCostValue(int) 

    /**
     * Method getCostValue
     */
    public double[] getCostValue()
    {
        int size = _costValueList.size();
        double[] mArray = new double[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = ((Double)_costValueList.get(index)).doubleValue();
        }
        return mArray;
    } //-- double[] getCostValue() 

    /**
     * Method getCostValueCount
     */
    public int getCostValueCount()
    {
        return _costValueList.size();
    } //-- int getCostValueCount() 

    /**
     * Method getDudXMLChoice
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.DudXMLChoice getDudXMLChoice(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dudXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.DudXMLChoice) _dudXMLChoiceList.get(index);
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice getDudXMLChoice(int) 

    /**
     * Method getDudXMLChoice
     */
    public org.openda.core.io.castorgenerated.DudXMLChoice[] getDudXMLChoice()
    {
        int size = _dudXMLChoiceList.size();
        org.openda.core.io.castorgenerated.DudXMLChoice[] mArray = new org.openda.core.io.castorgenerated.DudXMLChoice[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.DudXMLChoice) _dudXMLChoiceList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice[] getDudXMLChoice() 

    /**
     * Method getDudXMLChoice2
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.DudXMLChoice2 getDudXMLChoice2(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dudXMLChoice2List.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.DudXMLChoice2) _dudXMLChoice2List.get(index);
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice2 getDudXMLChoice2(int) 

    /**
     * Method getDudXMLChoice2
     */
    public org.openda.core.io.castorgenerated.DudXMLChoice2[] getDudXMLChoice2()
    {
        int size = _dudXMLChoice2List.size();
        org.openda.core.io.castorgenerated.DudXMLChoice2[] mArray = new org.openda.core.io.castorgenerated.DudXMLChoice2[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.DudXMLChoice2) _dudXMLChoice2List.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.DudXMLChoice2[] getDudXMLChoice2() 

    /**
     * Method getDudXMLChoice2Count
     */
    public int getDudXMLChoice2Count()
    {
        return _dudXMLChoice2List.size();
    } //-- int getDudXMLChoice2Count() 

    /**
     * Method getDudXMLChoiceCount
     */
    public int getDudXMLChoiceCount()
    {
        return _dudXMLChoiceList.size();
    } //-- int getDudXMLChoiceCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeCostValue
     * 
     * @param vCostValue
     */
    public boolean removeCostValue(double vCostValue)
    {
        boolean removed = _costValueList.remove(new Double(vCostValue));
        return removed;
    } //-- boolean removeCostValue(double) 

    /**
     * Method removeDudXMLChoice
     * 
     * @param vDudXMLChoice
     */
    public boolean removeDudXMLChoice(org.openda.core.io.castorgenerated.DudXMLChoice vDudXMLChoice)
    {
        boolean removed = _dudXMLChoiceList.remove(vDudXMLChoice);
        return removed;
    } //-- boolean removeDudXMLChoice(org.openda.core.io.castorgenerated.DudXMLChoice) 

    /**
     * Method removeDudXMLChoice2
     * 
     * @param vDudXMLChoice2
     */
    public boolean removeDudXMLChoice2(org.openda.core.io.castorgenerated.DudXMLChoice2 vDudXMLChoice2)
    {
        boolean removed = _dudXMLChoice2List.remove(vDudXMLChoice2);
        return removed;
    } //-- boolean removeDudXMLChoice2(org.openda.core.io.castorgenerated.DudXMLChoice2) 

    /**
     * Method setCostValue
     * 
     * @param index
     * @param vCostValue
     */
    public void setCostValue(int index, double vCostValue)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _costValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _costValueList.set(index, new Double(vCostValue));
    } //-- void setCostValue(int, double) 

    /**
     * Method setCostValue
     * 
     * @param costValueArray
     */
    public void setCostValue(double[] costValueArray)
    {
        //-- copy array
        _costValueList.clear();
        for (int i = 0; i < costValueArray.length; i++) {
            _costValueList.add(new Double(costValueArray[i]));
        }
    } //-- void setCostValue(double) 

    /**
     * Method setDudXMLChoice
     * 
     * @param index
     * @param vDudXMLChoice
     */
    public void setDudXMLChoice(int index, org.openda.core.io.castorgenerated.DudXMLChoice vDudXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dudXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _dudXMLChoiceList.set(index, vDudXMLChoice);
    } //-- void setDudXMLChoice(int, org.openda.core.io.castorgenerated.DudXMLChoice) 

    /**
     * Method setDudXMLChoice
     * 
     * @param dudXMLChoiceArray
     */
    public void setDudXMLChoice(org.openda.core.io.castorgenerated.DudXMLChoice[] dudXMLChoiceArray)
    {
        //-- copy array
        _dudXMLChoiceList.clear();
        for (int i = 0; i < dudXMLChoiceArray.length; i++) {
            _dudXMLChoiceList.add(dudXMLChoiceArray[i]);
        }
    } //-- void setDudXMLChoice(org.openda.core.io.castorgenerated.DudXMLChoice) 

    /**
     * Method setDudXMLChoice2
     * 
     * @param index
     * @param vDudXMLChoice2
     */
    public void setDudXMLChoice2(int index, org.openda.core.io.castorgenerated.DudXMLChoice2 vDudXMLChoice2)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dudXMLChoice2List.size())) {
            throw new IndexOutOfBoundsException();
        }
        _dudXMLChoice2List.set(index, vDudXMLChoice2);
    } //-- void setDudXMLChoice2(int, org.openda.core.io.castorgenerated.DudXMLChoice2) 

    /**
     * Method setDudXMLChoice2
     * 
     * @param dudXMLChoice2Array
     */
    public void setDudXMLChoice2(org.openda.core.io.castorgenerated.DudXMLChoice2[] dudXMLChoice2Array)
    {
        //-- copy array
        _dudXMLChoice2List.clear();
        for (int i = 0; i < dudXMLChoice2Array.length; i++) {
            _dudXMLChoice2List.add(dudXMLChoice2Array[i]);
        }
    } //-- void setDudXMLChoice2(org.openda.core.io.castorgenerated.DudXMLChoice2) 

    /**
     * Method unmarshalDudXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.DudXML unmarshalDudXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.DudXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.DudXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.DudXML unmarshalDudXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
