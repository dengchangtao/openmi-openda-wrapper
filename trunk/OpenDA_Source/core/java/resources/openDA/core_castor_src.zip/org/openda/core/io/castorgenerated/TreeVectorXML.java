/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TreeVectorXML.
 * 
 * @version $Revision$ $Date$
 */
public class TreeVectorXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _id
     */
    private java.lang.String _id;

    /**
     * Field _caption
     */
    private java.lang.String _caption;

    /**
     * Field _excludeFromVector
     */
    private boolean _excludeFromVector;

    /**
     * keeps track of state for field: _excludeFromVector
     */
    private boolean _has_excludeFromVector;

    /**
     * Field _className
     */
    private java.lang.String _className;

    /**
     * Field _description
     */
    private java.lang.String _description;

    /**
     * Field _treeVectorXMLChoiceList
     */
    private java.util.ArrayList _treeVectorXMLChoiceList;


      //----------------/
     //- Constructors -/
    //----------------/

    public TreeVectorXML() {
        super();
        _treeVectorXMLChoiceList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addTreeVectorXMLChoice
     * 
     * @param vTreeVectorXMLChoice
     */
    public void addTreeVectorXMLChoice(org.openda.core.io.castorgenerated.TreeVectorXMLChoice vTreeVectorXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _treeVectorXMLChoiceList.add(vTreeVectorXMLChoice);
    } //-- void addTreeVectorXMLChoice(org.openda.core.io.castorgenerated.TreeVectorXMLChoice) 

    /**
     * Method addTreeVectorXMLChoice
     * 
     * @param index
     * @param vTreeVectorXMLChoice
     */
    public void addTreeVectorXMLChoice(int index, org.openda.core.io.castorgenerated.TreeVectorXMLChoice vTreeVectorXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _treeVectorXMLChoiceList.add(index, vTreeVectorXMLChoice);
    } //-- void addTreeVectorXMLChoice(int, org.openda.core.io.castorgenerated.TreeVectorXMLChoice) 

    /**
     * Method clearTreeVectorXMLChoice
     */
    public void clearTreeVectorXMLChoice()
    {
        _treeVectorXMLChoiceList.clear();
    } //-- void clearTreeVectorXMLChoice() 

    /**
     * Method deleteExcludeFromVector
     */
    public void deleteExcludeFromVector()
    {
        this._has_excludeFromVector= false;
    } //-- void deleteExcludeFromVector() 

    /**
     * Method enumerateTreeVectorXMLChoice
     */
    public java.util.Enumeration enumerateTreeVectorXMLChoice()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_treeVectorXMLChoiceList.iterator());
    } //-- java.util.Enumeration enumerateTreeVectorXMLChoice() 

    /**
     * Returns the value of field 'caption'.
     * 
     * @return the value of field 'caption'.
     */
    public java.lang.String getCaption()
    {
        return this._caption;
    } //-- java.lang.String getCaption() 

    /**
     * Returns the value of field 'className'.
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'description'.
     * 
     * @return the value of field 'description'.
     */
    public java.lang.String getDescription()
    {
        return this._description;
    } //-- java.lang.String getDescription() 

    /**
     * Returns the value of field 'excludeFromVector'.
     * 
     * @return the value of field 'excludeFromVector'.
     */
    public boolean getExcludeFromVector()
    {
        return this._excludeFromVector;
    } //-- boolean getExcludeFromVector() 

    /**
     * Returns the value of field 'id'.
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Method getTreeVectorXMLChoice
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TreeVectorXMLChoice getTreeVectorXMLChoice(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _treeVectorXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TreeVectorXMLChoice) _treeVectorXMLChoiceList.get(index);
    } //-- org.openda.core.io.castorgenerated.TreeVectorXMLChoice getTreeVectorXMLChoice(int) 

    /**
     * Method getTreeVectorXMLChoice
     */
    public org.openda.core.io.castorgenerated.TreeVectorXMLChoice[] getTreeVectorXMLChoice()
    {
        int size = _treeVectorXMLChoiceList.size();
        org.openda.core.io.castorgenerated.TreeVectorXMLChoice[] mArray = new org.openda.core.io.castorgenerated.TreeVectorXMLChoice[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TreeVectorXMLChoice) _treeVectorXMLChoiceList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXMLChoice[] getTreeVectorXMLChoice() 

    /**
     * Method getTreeVectorXMLChoiceCount
     */
    public int getTreeVectorXMLChoiceCount()
    {
        return _treeVectorXMLChoiceList.size();
    } //-- int getTreeVectorXMLChoiceCount() 

    /**
     * Method hasExcludeFromVector
     */
    public boolean hasExcludeFromVector()
    {
        return this._has_excludeFromVector;
    } //-- boolean hasExcludeFromVector() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeTreeVectorXMLChoice
     * 
     * @param vTreeVectorXMLChoice
     */
    public boolean removeTreeVectorXMLChoice(org.openda.core.io.castorgenerated.TreeVectorXMLChoice vTreeVectorXMLChoice)
    {
        boolean removed = _treeVectorXMLChoiceList.remove(vTreeVectorXMLChoice);
        return removed;
    } //-- boolean removeTreeVectorXMLChoice(org.openda.core.io.castorgenerated.TreeVectorXMLChoice) 

    /**
     * Sets the value of field 'caption'.
     * 
     * @param caption the value of field 'caption'.
     */
    public void setCaption(java.lang.String caption)
    {
        this._caption = caption;
    } //-- void setCaption(java.lang.String) 

    /**
     * Sets the value of field 'className'.
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'description'.
     * 
     * @param description the value of field 'description'.
     */
    public void setDescription(java.lang.String description)
    {
        this._description = description;
    } //-- void setDescription(java.lang.String) 

    /**
     * Sets the value of field 'excludeFromVector'.
     * 
     * @param excludeFromVector the value of field
     * 'excludeFromVector'.
     */
    public void setExcludeFromVector(boolean excludeFromVector)
    {
        this._excludeFromVector = excludeFromVector;
        this._has_excludeFromVector = true;
    } //-- void setExcludeFromVector(boolean) 

    /**
     * Sets the value of field 'id'.
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Method setTreeVectorXMLChoice
     * 
     * @param index
     * @param vTreeVectorXMLChoice
     */
    public void setTreeVectorXMLChoice(int index, org.openda.core.io.castorgenerated.TreeVectorXMLChoice vTreeVectorXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _treeVectorXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _treeVectorXMLChoiceList.set(index, vTreeVectorXMLChoice);
    } //-- void setTreeVectorXMLChoice(int, org.openda.core.io.castorgenerated.TreeVectorXMLChoice) 

    /**
     * Method setTreeVectorXMLChoice
     * 
     * @param treeVectorXMLChoiceArray
     */
    public void setTreeVectorXMLChoice(org.openda.core.io.castorgenerated.TreeVectorXMLChoice[] treeVectorXMLChoiceArray)
    {
        //-- copy array
        _treeVectorXMLChoiceList.clear();
        for (int i = 0; i < treeVectorXMLChoiceArray.length; i++) {
            _treeVectorXMLChoiceList.add(treeVectorXMLChoiceArray[i]);
        }
    } //-- void setTreeVectorXMLChoice(org.openda.core.io.castorgenerated.TreeVectorXMLChoice) 

    /**
     * Method unmarshalTreeVectorXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TreeVectorXML unmarshalTreeVectorXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TreeVectorXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TreeVectorXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML unmarshalTreeVectorXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
