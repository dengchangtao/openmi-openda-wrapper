/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML;
import org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML;
import org.xml.sax.ContentHandler;

/**
 * Class ResultItemXML.
 * 
 * @version $Revision$ $Date$
 */
public class ResultItemXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Identity (name) of the result item
     */
    private java.lang.String _id = "any";

    /**
     * Minimum size (number of elements) of the result item.
     */
    private int _minSize = 1;

    /**
     * keeps track of state for field: _minSize
     */
    private boolean _has_minSize;

    /**
     * Maximum size (number of elements) of the result item.
     */
    private int _maxSize = 2147483647;

    /**
     * keeps track of state for field: _maxSize
     */
    private boolean _has_maxSize;

    /**
     * Grouping of the result items according to their level of
     * significance: none, essential,normal,verbose,all.
     */
    private java.lang.String _outputLevel = "all";

    /**
     * Context in which the result item should be written in the
     * output, for example model instance id, iteration id, etc.
     */
    private java.lang.String _context = "any";

    /**
     * Switch output of result item on or off
     */
    private boolean _doLog = true;

    /**
     * keeps track of state for field: _doLog
     */
    private boolean _has_doLog;

    /**
     * Source of the result item ("observer", "model", "algorithm"
     * or "other")
     */
    private org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML _source;

    /**
     * Type of message ("step", "inner", "outer", or "evaluation").
     * Deprecated function, will not be supported in future
     * versions of OpenDA.
     */
    private java.util.ArrayList _messageTypeList;


      //----------------/
     //- Constructors -/
    //----------------/

    public ResultItemXML() {
        super();
        setId("any");
        setOutputLevel("all");
        setContext("any");
        _messageTypeList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.ResultItemXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addMessageType
     * 
     * @param vMessageType
     */
    public void addMessageType(org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML vMessageType)
        throws java.lang.IndexOutOfBoundsException
    {
        if (!(_messageTypeList.size() < 4)) {
            throw new IndexOutOfBoundsException();
        }
        _messageTypeList.add(vMessageType);
    } //-- void addMessageType(org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML) 

    /**
     * Method addMessageType
     * 
     * @param index
     * @param vMessageType
     */
    public void addMessageType(int index, org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML vMessageType)
        throws java.lang.IndexOutOfBoundsException
    {
        if (!(_messageTypeList.size() < 4)) {
            throw new IndexOutOfBoundsException();
        }
        _messageTypeList.add(index, vMessageType);
    } //-- void addMessageType(int, org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML) 

    /**
     * Method clearMessageType
     */
    public void clearMessageType()
    {
        _messageTypeList.clear();
    } //-- void clearMessageType() 

    /**
     * Method deleteDoLog
     */
    public void deleteDoLog()
    {
        this._has_doLog= false;
    } //-- void deleteDoLog() 

    /**
     * Method deleteMaxSize
     */
    public void deleteMaxSize()
    {
        this._has_maxSize= false;
    } //-- void deleteMaxSize() 

    /**
     * Method deleteMinSize
     */
    public void deleteMinSize()
    {
        this._has_minSize= false;
    } //-- void deleteMinSize() 

    /**
     * Method enumerateMessageType
     */
    public java.util.Enumeration enumerateMessageType()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_messageTypeList.iterator());
    } //-- java.util.Enumeration enumerateMessageType() 

    /**
     * Returns the value of field 'context'. The field 'context'
     * has the following description: Context in which the result
     * item should be written in the output, for example model
     * instance id, iteration id, etc.
     * 
     * @return the value of field 'context'.
     */
    public java.lang.String getContext()
    {
        return this._context;
    } //-- java.lang.String getContext() 

    /**
     * Returns the value of field 'doLog'. The field 'doLog' has
     * the following description: Switch output of result item on
     * or off
     * 
     * @return the value of field 'doLog'.
     */
    public boolean getDoLog()
    {
        return this._doLog;
    } //-- boolean getDoLog() 

    /**
     * Returns the value of field 'id'. The field 'id' has the
     * following description: Identity (name) of the result item
     * 
     * @return the value of field 'id'.
     */
    public java.lang.String getId()
    {
        return this._id;
    } //-- java.lang.String getId() 

    /**
     * Returns the value of field 'maxSize'. The field 'maxSize'
     * has the following description: Maximum size (number of
     * elements) of the result item.
     * 
     * @return the value of field 'maxSize'.
     */
    public int getMaxSize()
    {
        return this._maxSize;
    } //-- int getMaxSize() 

    /**
     * Method getMessageType
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML getMessageType(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _messageTypeList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML) _messageTypeList.get(index);
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML getMessageType(int) 

    /**
     * Method getMessageType
     */
    public org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML[] getMessageType()
    {
        int size = _messageTypeList.size();
        org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML[] mArray = new org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML) _messageTypeList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML[] getMessageType() 

    /**
     * Method getMessageTypeCount
     */
    public int getMessageTypeCount()
    {
        return _messageTypeList.size();
    } //-- int getMessageTypeCount() 

    /**
     * Returns the value of field 'minSize'. The field 'minSize'
     * has the following description: Minimum size (number of
     * elements) of the result item.
     * 
     * @return the value of field 'minSize'.
     */
    public int getMinSize()
    {
        return this._minSize;
    } //-- int getMinSize() 

    /**
     * Returns the value of field 'outputLevel'. The field
     * 'outputLevel' has the following description: Grouping of the
     * result items according to their level of significance: none,
     * essential,normal,verbose,all.
     * 
     * @return the value of field 'outputLevel'.
     */
    public java.lang.String getOutputLevel()
    {
        return this._outputLevel;
    } //-- java.lang.String getOutputLevel() 

    /**
     * Returns the value of field 'source'. The field 'source' has
     * the following description: Source of the result item
     * ("observer", "model", "algorithm" or "other")
     * 
     * @return the value of field 'source'.
     */
    public org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML getSource()
    {
        return this._source;
    } //-- org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML getSource() 

    /**
     * Method hasDoLog
     */
    public boolean hasDoLog()
    {
        return this._has_doLog;
    } //-- boolean hasDoLog() 

    /**
     * Method hasMaxSize
     */
    public boolean hasMaxSize()
    {
        return this._has_maxSize;
    } //-- boolean hasMaxSize() 

    /**
     * Method hasMinSize
     */
    public boolean hasMinSize()
    {
        return this._has_minSize;
    } //-- boolean hasMinSize() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeMessageType
     * 
     * @param vMessageType
     */
    public boolean removeMessageType(org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML vMessageType)
    {
        boolean removed = _messageTypeList.remove(vMessageType);
        return removed;
    } //-- boolean removeMessageType(org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML) 

    /**
     * Sets the value of field 'context'. The field 'context' has
     * the following description: Context in which the result item
     * should be written in the output, for example model instance
     * id, iteration id, etc.
     * 
     * @param context the value of field 'context'.
     */
    public void setContext(java.lang.String context)
    {
        this._context = context;
    } //-- void setContext(java.lang.String) 

    /**
     * Sets the value of field 'doLog'. The field 'doLog' has the
     * following description: Switch output of result item on or
     * off
     * 
     * @param doLog the value of field 'doLog'.
     */
    public void setDoLog(boolean doLog)
    {
        this._doLog = doLog;
        this._has_doLog = true;
    } //-- void setDoLog(boolean) 

    /**
     * Sets the value of field 'id'. The field 'id' has the
     * following description: Identity (name) of the result item
     * 
     * @param id the value of field 'id'.
     */
    public void setId(java.lang.String id)
    {
        this._id = id;
    } //-- void setId(java.lang.String) 

    /**
     * Sets the value of field 'maxSize'. The field 'maxSize' has
     * the following description: Maximum size (number of elements)
     * of the result item.
     * 
     * @param maxSize the value of field 'maxSize'.
     */
    public void setMaxSize(int maxSize)
    {
        this._maxSize = maxSize;
        this._has_maxSize = true;
    } //-- void setMaxSize(int) 

    /**
     * Method setMessageType
     * 
     * @param index
     * @param vMessageType
     */
    public void setMessageType(int index, org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML vMessageType)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _messageTypeList.size())) {
            throw new IndexOutOfBoundsException();
        }
        if (!(index < 4)) {
            throw new IndexOutOfBoundsException();
        }
        _messageTypeList.set(index, vMessageType);
    } //-- void setMessageType(int, org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML) 

    /**
     * Method setMessageType
     * 
     * @param messageTypeArray
     */
    public void setMessageType(org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML[] messageTypeArray)
    {
        //-- copy array
        _messageTypeList.clear();
        for (int i = 0; i < messageTypeArray.length; i++) {
            _messageTypeList.add(messageTypeArray[i]);
        }
    } //-- void setMessageType(org.openda.core.io.castorgenerated.types.ResultWriterMessageTypeXML) 

    /**
     * Sets the value of field 'minSize'. The field 'minSize' has
     * the following description: Minimum size (number of elements)
     * of the result item.
     * 
     * @param minSize the value of field 'minSize'.
     */
    public void setMinSize(int minSize)
    {
        this._minSize = minSize;
        this._has_minSize = true;
    } //-- void setMinSize(int) 

    /**
     * Sets the value of field 'outputLevel'. The field
     * 'outputLevel' has the following description: Grouping of the
     * result items according to their level of significance: none,
     * essential,normal,verbose,all.
     * 
     * @param outputLevel the value of field 'outputLevel'.
     */
    public void setOutputLevel(java.lang.String outputLevel)
    {
        this._outputLevel = outputLevel;
    } //-- void setOutputLevel(java.lang.String) 

    /**
     * Sets the value of field 'source'. The field 'source' has the
     * following description: Source of the result item
     * ("observer", "model", "algorithm" or "other")
     * 
     * @param source the value of field 'source'.
     */
    public void setSource(org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML source)
    {
        this._source = source;
    } //-- void setSource(org.openda.core.io.castorgenerated.types.ResultWriterSourceTypeXML) 

    /**
     * Method unmarshalResultItemXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.ResultItemXML unmarshalResultItemXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.ResultItemXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.ResultItemXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.ResultItemXML unmarshalResultItemXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
