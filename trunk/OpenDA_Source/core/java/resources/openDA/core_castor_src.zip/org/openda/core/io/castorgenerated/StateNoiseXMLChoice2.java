/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class StateNoiseXMLChoice2.
 * 
 * @version $Revision$ $Date$
 */
public class StateNoiseXMLChoice2 implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The noise model is fully specified in the uncertainty module
     */
    private org.openda.core.io.castorgenerated.StateNoiseUncertainItemXML _uncertainItem;

    /**
     * The PDF of the noise model is specified in the uncertainty
     * module, the ARMA constants are specified here
     */
    private org.openda.core.io.castorgenerated.StateNoiseUncertainItemWithArmaConstantsXML _uncertainItemWithArmaConstants;

    /**
     * Both the noise model's PDF (normal distribution) and the
     * ARMA constants are specified here
     */
    private org.openda.core.io.castorgenerated.StateNoiseArmaModelXML _armaModel;

    /**
     * The standard deviation and the decoralation time scale of
     * the AR1 model is specified
     */
    private org.openda.core.io.castorgenerated.StateNoiseAr1ModelXML _ar1Model;


      //----------------/
     //- Constructors -/
    //----------------/

    public StateNoiseXMLChoice2() {
        super();
    } //-- org.openda.core.io.castorgenerated.StateNoiseXMLChoice2()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'ar1Model'. The field 'ar1Model'
     * has the following description: The standard deviation and
     * the decoralation time scale of the AR1 model is specified
     * 
     * @return the value of field 'ar1Model'.
     */
    public org.openda.core.io.castorgenerated.StateNoiseAr1ModelXML getAr1Model()
    {
        return this._ar1Model;
    } //-- org.openda.core.io.castorgenerated.StateNoiseAr1ModelXML getAr1Model() 

    /**
     * Returns the value of field 'armaModel'. The field
     * 'armaModel' has the following description: Both the noise
     * model's PDF (normal distribution) and the ARMA constants are
     * specified here
     * 
     * @return the value of field 'armaModel'.
     */
    public org.openda.core.io.castorgenerated.StateNoiseArmaModelXML getArmaModel()
    {
        return this._armaModel;
    } //-- org.openda.core.io.castorgenerated.StateNoiseArmaModelXML getArmaModel() 

    /**
     * Returns the value of field 'uncertainItem'. The field
     * 'uncertainItem' has the following description: The noise
     * model is fully specified in the uncertainty module
     * 
     * @return the value of field 'uncertainItem'.
     */
    public org.openda.core.io.castorgenerated.StateNoiseUncertainItemXML getUncertainItem()
    {
        return this._uncertainItem;
    } //-- org.openda.core.io.castorgenerated.StateNoiseUncertainItemXML getUncertainItem() 

    /**
     * Returns the value of field 'uncertainItemWithArmaConstants'.
     * The field 'uncertainItemWithArmaConstants' has the following
     * description: The PDF of the noise model is specified in the
     * uncertainty module, the ARMA constants are specified here
     * 
     * @return the value of field 'uncertainItemWithArmaConstants'.
     */
    public org.openda.core.io.castorgenerated.StateNoiseUncertainItemWithArmaConstantsXML getUncertainItemWithArmaConstants()
    {
        return this._uncertainItemWithArmaConstants;
    } //-- org.openda.core.io.castorgenerated.StateNoiseUncertainItemWithArmaConstantsXML getUncertainItemWithArmaConstants() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'ar1Model'. The field 'ar1Model' has
     * the following description: The standard deviation and the
     * decoralation time scale of the AR1 model is specified
     * 
     * @param ar1Model the value of field 'ar1Model'.
     */
    public void setAr1Model(org.openda.core.io.castorgenerated.StateNoiseAr1ModelXML ar1Model)
    {
        this._ar1Model = ar1Model;
    } //-- void setAr1Model(org.openda.core.io.castorgenerated.StateNoiseAr1ModelXML) 

    /**
     * Sets the value of field 'armaModel'. The field 'armaModel'
     * has the following description: Both the noise model's PDF
     * (normal distribution) and the ARMA constants are specified
     * here
     * 
     * @param armaModel the value of field 'armaModel'.
     */
    public void setArmaModel(org.openda.core.io.castorgenerated.StateNoiseArmaModelXML armaModel)
    {
        this._armaModel = armaModel;
    } //-- void setArmaModel(org.openda.core.io.castorgenerated.StateNoiseArmaModelXML) 

    /**
     * Sets the value of field 'uncertainItem'. The field
     * 'uncertainItem' has the following description: The noise
     * model is fully specified in the uncertainty module
     * 
     * @param uncertainItem the value of field 'uncertainItem'.
     */
    public void setUncertainItem(org.openda.core.io.castorgenerated.StateNoiseUncertainItemXML uncertainItem)
    {
        this._uncertainItem = uncertainItem;
    } //-- void setUncertainItem(org.openda.core.io.castorgenerated.StateNoiseUncertainItemXML) 

    /**
     * Sets the value of field 'uncertainItemWithArmaConstants'.
     * The field 'uncertainItemWithArmaConstants' has the following
     * description: The PDF of the noise model is specified in the
     * uncertainty module, the ARMA constants are specified here
     * 
     * @param uncertainItemWithArmaConstants the value of field
     * 'uncertainItemWithArmaConstants'.
     */
    public void setUncertainItemWithArmaConstants(org.openda.core.io.castorgenerated.StateNoiseUncertainItemWithArmaConstantsXML uncertainItemWithArmaConstants)
    {
        this._uncertainItemWithArmaConstants = uncertainItemWithArmaConstants;
    } //-- void setUncertainItemWithArmaConstants(org.openda.core.io.castorgenerated.StateNoiseUncertainItemWithArmaConstantsXML) 

    /**
     * Method unmarshalStateNoiseXMLChoice2
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.StateNoiseXMLChoice2 unmarshalStateNoiseXMLChoice2(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.StateNoiseXMLChoice2) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.StateNoiseXMLChoice2.class, reader);
    } //-- org.openda.core.io.castorgenerated.StateNoiseXMLChoice2 unmarshalStateNoiseXMLChoice2(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
