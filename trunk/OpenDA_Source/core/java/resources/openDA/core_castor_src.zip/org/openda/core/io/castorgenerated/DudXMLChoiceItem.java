/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class DudXMLChoiceItem.
 * 
 * @version $Revision$ $Date$
 */
public class DudXMLChoiceItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _params
     */
    private org.openda.core.io.castorgenerated.TreeVectorXML _params;

    /**
     * Field _paramVector
     */
    private java.lang.String _paramVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public DudXMLChoiceItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.DudXMLChoiceItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'paramVector'.
     * 
     * @return the value of field 'paramVector'.
     */
    public java.lang.String getParamVector()
    {
        return this._paramVector;
    } //-- java.lang.String getParamVector() 

    /**
     * Returns the value of field 'params'.
     * 
     * @return the value of field 'params'.
     */
    public org.openda.core.io.castorgenerated.TreeVectorXML getParams()
    {
        return this._params;
    } //-- org.openda.core.io.castorgenerated.TreeVectorXML getParams() 

    /**
     * Sets the value of field 'paramVector'.
     * 
     * @param paramVector the value of field 'paramVector'.
     */
    public void setParamVector(java.lang.String paramVector)
    {
        this._paramVector = paramVector;
    } //-- void setParamVector(java.lang.String) 

    /**
     * Sets the value of field 'params'.
     * 
     * @param params the value of field 'params'.
     */
    public void setParams(org.openda.core.io.castorgenerated.TreeVectorXML params)
    {
        this._params = params;
    } //-- void setParams(org.openda.core.io.castorgenerated.TreeVectorXML) 

}
