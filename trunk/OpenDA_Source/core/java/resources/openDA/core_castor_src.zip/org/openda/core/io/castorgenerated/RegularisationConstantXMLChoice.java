/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class RegularisationConstantXMLChoice.
 * 
 * @version $Revision$ $Date$
 */
public class RegularisationConstantXMLChoice implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Set the standard deviation of this parameter and the method
     * how the parameter should be corrected
     */
    private org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML _stdDev;

    /**
     * The uncertainy of this parameter is specified in the
     * uncertaintyModule mentioned in the top of the present
     * stochastic model configuration
     */
    private org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML _uncertainItem;


      //----------------/
     //- Constructors -/
    //----------------/

    public RegularisationConstantXMLChoice() {
        super();
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'stdDev'. The field 'stdDev' has
     * the following description: Set the standard deviation of
     * this parameter and the method how the parameter should be
     * corrected
     * 
     * @return the value of field 'stdDev'.
     */
    public org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML getStdDev()
    {
        return this._stdDev;
    } //-- org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML getStdDev() 

    /**
     * Returns the value of field 'uncertainItem'. The field
     * 'uncertainItem' has the following description: The
     * uncertainy of this parameter is specified in the
     * uncertaintyModule mentioned in the top of the present
     * stochastic model configuration
     * 
     * @return the value of field 'uncertainItem'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML getUncertainItem()
    {
        return this._uncertainItem;
    } //-- org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML getUncertainItem() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'stdDev'. The field 'stdDev' has the
     * following description: Set the standard deviation of this
     * parameter and the method how the parameter should be
     * corrected
     * 
     * @param stdDev the value of field 'stdDev'.
     */
    public void setStdDev(org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML stdDev)
    {
        this._stdDev = stdDev;
    } //-- void setStdDev(org.openda.core.io.castorgenerated.StandardDeviationAndTransformationXML) 

    /**
     * Sets the value of field 'uncertainItem'. The field
     * 'uncertainItem' has the following description: The
     * uncertainy of this parameter is specified in the
     * uncertaintyModule mentioned in the top of the present
     * stochastic model configuration
     * 
     * @param uncertainItem the value of field 'uncertainItem'.
     */
    public void setUncertainItem(org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML uncertainItem)
    {
        this._uncertainItem = uncertainItem;
    } //-- void setUncertainItem(org.openda.core.io.castorgenerated.BlackBoxStochModelUncertainParameterXML) 

    /**
     * Method unmarshalRegularisationConstantXMLChoice
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice unmarshalRegularisationConstantXMLChoice(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice.class, reader);
    } //-- org.openda.core.io.castorgenerated.RegularisationConstantXMLChoice unmarshalRegularisationConstantXMLChoice(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
