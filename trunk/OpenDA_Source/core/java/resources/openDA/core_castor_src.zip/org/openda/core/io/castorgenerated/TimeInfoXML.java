/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.Date;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class TimeInfoXML.
 * 
 * @version $Revision$ $Date$
 */
public class TimeInfoXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the start time of the simulation (yyyy-mm-ddThh:mm:ss
     */
    private java.util.Date _start;

    /**
     * Specify the end time of the simulation (yyyy-mm-ddThh:mm:ss)
     */
    private java.util.Date _end;

    /**
     * Specify the time step of the simulation in seconds
     */
    private double _timeStepInSeconds;

    /**
     * keeps track of state for field: _timeStepInSeconds
     */
    private boolean _has_timeStepInSeconds;


      //----------------/
     //- Constructors -/
    //----------------/

    public TimeInfoXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.TimeInfoXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method deleteTimeStepInSeconds
     */
    public void deleteTimeStepInSeconds()
    {
        this._has_timeStepInSeconds= false;
    } //-- void deleteTimeStepInSeconds() 

    /**
     * Returns the value of field 'end'. The field 'end' has the
     * following description: Specify the end time of the
     * simulation (yyyy-mm-ddThh:mm:ss)
     * 
     * @return the value of field 'end'.
     */
    public java.util.Date getEnd()
    {
        return this._end;
    } //-- java.util.Date getEnd() 

    /**
     * Returns the value of field 'start'. The field 'start' has
     * the following description: Specify the start time of the
     * simulation (yyyy-mm-ddThh:mm:ss)
     * 
     * @return the value of field 'start'.
     */
    public java.util.Date getStart()
    {
        return this._start;
    } //-- java.util.Date getStart() 

    /**
     * Returns the value of field 'timeStepInSeconds'. The field
     * 'timeStepInSeconds' has the following description: Specify
     * the time step of the simulation in seconds
     * 
     * @return the value of field 'timeStepInSeconds'.
     */
    public double getTimeStepInSeconds()
    {
        return this._timeStepInSeconds;
    } //-- double getTimeStepInSeconds() 

    /**
     * Method hasTimeStepInSeconds
     */
    public boolean hasTimeStepInSeconds()
    {
        return this._has_timeStepInSeconds;
    } //-- boolean hasTimeStepInSeconds() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'end'. The field 'end' has the
     * following description: Specify the end time of the
     * simulation (yyyy-mm-ddThh:mm:ss)
     * 
     * @param end the value of field 'end'.
     */
    public void setEnd(java.util.Date end)
    {
        this._end = end;
    } //-- void setEnd(java.util.Date) 

    /**
     * Sets the value of field 'start'. The field 'start' has the
     * following description: Specify the start time of the
     * simulation (yyyy-mm-ddThh:mm:ss)
     * 
     * @param start the value of field 'start'.
     */
    public void setStart(java.util.Date start)
    {
        this._start = start;
    } //-- void setStart(java.util.Date) 

    /**
     * Sets the value of field 'timeStepInSeconds'. The field
     * 'timeStepInSeconds' has the following description: Specify
     * the time step of the simulation in seconds
     * 
     * @param timeStepInSeconds the value of field
     * 'timeStepInSeconds'.
     */
    public void setTimeStepInSeconds(double timeStepInSeconds)
    {
        this._timeStepInSeconds = timeStepInSeconds;
        this._has_timeStepInSeconds = true;
    } //-- void setTimeStepInSeconds(double) 

    /**
     * Method unmarshalTimeInfoXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.TimeInfoXML unmarshalTimeInfoXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.TimeInfoXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.TimeInfoXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.TimeInfoXML unmarshalTimeInfoXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
