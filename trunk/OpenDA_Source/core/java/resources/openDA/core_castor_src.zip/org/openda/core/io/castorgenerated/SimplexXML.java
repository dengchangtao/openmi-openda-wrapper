/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class SimplexXML.
 * 
 * @version $Revision$ $Date$
 */
public class SimplexXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _simplexXMLChoiceList
     */
    private java.util.ArrayList _simplexXMLChoiceList;

    /**
     * Field _costValueList
     */
    private java.util.ArrayList _costValueList;


      //----------------/
     //- Constructors -/
    //----------------/

    public SimplexXML() {
        super();
        _simplexXMLChoiceList = new ArrayList();
        _costValueList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.SimplexXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addCostValue
     * 
     * @param vCostValue
     */
    public void addCostValue(double vCostValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _costValueList.add(new Double(vCostValue));
    } //-- void addCostValue(double) 

    /**
     * Method addCostValue
     * 
     * @param index
     * @param vCostValue
     */
    public void addCostValue(int index, double vCostValue)
        throws java.lang.IndexOutOfBoundsException
    {
        _costValueList.add(index, new Double(vCostValue));
    } //-- void addCostValue(int, double) 

    /**
     * Method addSimplexXMLChoice
     * 
     * @param vSimplexXMLChoice
     */
    public void addSimplexXMLChoice(org.openda.core.io.castorgenerated.SimplexXMLChoice vSimplexXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _simplexXMLChoiceList.add(vSimplexXMLChoice);
    } //-- void addSimplexXMLChoice(org.openda.core.io.castorgenerated.SimplexXMLChoice) 

    /**
     * Method addSimplexXMLChoice
     * 
     * @param index
     * @param vSimplexXMLChoice
     */
    public void addSimplexXMLChoice(int index, org.openda.core.io.castorgenerated.SimplexXMLChoice vSimplexXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        _simplexXMLChoiceList.add(index, vSimplexXMLChoice);
    } //-- void addSimplexXMLChoice(int, org.openda.core.io.castorgenerated.SimplexXMLChoice) 

    /**
     * Method clearCostValue
     */
    public void clearCostValue()
    {
        _costValueList.clear();
    } //-- void clearCostValue() 

    /**
     * Method clearSimplexXMLChoice
     */
    public void clearSimplexXMLChoice()
    {
        _simplexXMLChoiceList.clear();
    } //-- void clearSimplexXMLChoice() 

    /**
     * Method enumerateCostValue
     */
    public java.util.Enumeration enumerateCostValue()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_costValueList.iterator());
    } //-- java.util.Enumeration enumerateCostValue() 

    /**
     * Method enumerateSimplexXMLChoice
     */
    public java.util.Enumeration enumerateSimplexXMLChoice()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_simplexXMLChoiceList.iterator());
    } //-- java.util.Enumeration enumerateSimplexXMLChoice() 

    /**
     * Method getCostValue
     * 
     * @param index
     */
    public double getCostValue(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _costValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return ((Double)_costValueList.get(index)).doubleValue();
    } //-- double getCostValue(int) 

    /**
     * Method getCostValue
     */
    public double[] getCostValue()
    {
        int size = _costValueList.size();
        double[] mArray = new double[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = ((Double)_costValueList.get(index)).doubleValue();
        }
        return mArray;
    } //-- double[] getCostValue() 

    /**
     * Method getCostValueCount
     */
    public int getCostValueCount()
    {
        return _costValueList.size();
    } //-- int getCostValueCount() 

    /**
     * Method getSimplexXMLChoice
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.SimplexXMLChoice getSimplexXMLChoice(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _simplexXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.SimplexXMLChoice) _simplexXMLChoiceList.get(index);
    } //-- org.openda.core.io.castorgenerated.SimplexXMLChoice getSimplexXMLChoice(int) 

    /**
     * Method getSimplexXMLChoice
     */
    public org.openda.core.io.castorgenerated.SimplexXMLChoice[] getSimplexXMLChoice()
    {
        int size = _simplexXMLChoiceList.size();
        org.openda.core.io.castorgenerated.SimplexXMLChoice[] mArray = new org.openda.core.io.castorgenerated.SimplexXMLChoice[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.SimplexXMLChoice) _simplexXMLChoiceList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.SimplexXMLChoice[] getSimplexXMLChoice() 

    /**
     * Method getSimplexXMLChoiceCount
     */
    public int getSimplexXMLChoiceCount()
    {
        return _simplexXMLChoiceList.size();
    } //-- int getSimplexXMLChoiceCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeCostValue
     * 
     * @param vCostValue
     */
    public boolean removeCostValue(double vCostValue)
    {
        boolean removed = _costValueList.remove(new Double(vCostValue));
        return removed;
    } //-- boolean removeCostValue(double) 

    /**
     * Method removeSimplexXMLChoice
     * 
     * @param vSimplexXMLChoice
     */
    public boolean removeSimplexXMLChoice(org.openda.core.io.castorgenerated.SimplexXMLChoice vSimplexXMLChoice)
    {
        boolean removed = _simplexXMLChoiceList.remove(vSimplexXMLChoice);
        return removed;
    } //-- boolean removeSimplexXMLChoice(org.openda.core.io.castorgenerated.SimplexXMLChoice) 

    /**
     * Method setCostValue
     * 
     * @param index
     * @param vCostValue
     */
    public void setCostValue(int index, double vCostValue)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _costValueList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _costValueList.set(index, new Double(vCostValue));
    } //-- void setCostValue(int, double) 

    /**
     * Method setCostValue
     * 
     * @param costValueArray
     */
    public void setCostValue(double[] costValueArray)
    {
        //-- copy array
        _costValueList.clear();
        for (int i = 0; i < costValueArray.length; i++) {
            _costValueList.add(new Double(costValueArray[i]));
        }
    } //-- void setCostValue(double) 

    /**
     * Method setSimplexXMLChoice
     * 
     * @param index
     * @param vSimplexXMLChoice
     */
    public void setSimplexXMLChoice(int index, org.openda.core.io.castorgenerated.SimplexXMLChoice vSimplexXMLChoice)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _simplexXMLChoiceList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _simplexXMLChoiceList.set(index, vSimplexXMLChoice);
    } //-- void setSimplexXMLChoice(int, org.openda.core.io.castorgenerated.SimplexXMLChoice) 

    /**
     * Method setSimplexXMLChoice
     * 
     * @param simplexXMLChoiceArray
     */
    public void setSimplexXMLChoice(org.openda.core.io.castorgenerated.SimplexXMLChoice[] simplexXMLChoiceArray)
    {
        //-- copy array
        _simplexXMLChoiceList.clear();
        for (int i = 0; i < simplexXMLChoiceArray.length; i++) {
            _simplexXMLChoiceList.add(simplexXMLChoiceArray[i]);
        }
    } //-- void setSimplexXMLChoice(org.openda.core.io.castorgenerated.SimplexXMLChoice) 

    /**
     * Method unmarshalSimplexXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.SimplexXML unmarshalSimplexXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.SimplexXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.SimplexXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.SimplexXML unmarshalSimplexXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
