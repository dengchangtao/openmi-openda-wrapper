/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class InputOutputXML.
 * 
 * @version $Revision$ $Date$
 */
public class InputOutputXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the input/output object
     */
    private java.util.ArrayList _ioObjectList;


      //----------------/
     //- Constructors -/
    //----------------/

    public InputOutputXML() {
        super();
        _ioObjectList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.InputOutputXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addIoObject
     * 
     * @param vIoObject
     */
    public void addIoObject(org.openda.core.io.castorgenerated.IoObjectXML vIoObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _ioObjectList.add(vIoObject);
    } //-- void addIoObject(org.openda.core.io.castorgenerated.IoObjectXML) 

    /**
     * Method addIoObject
     * 
     * @param index
     * @param vIoObject
     */
    public void addIoObject(int index, org.openda.core.io.castorgenerated.IoObjectXML vIoObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _ioObjectList.add(index, vIoObject);
    } //-- void addIoObject(int, org.openda.core.io.castorgenerated.IoObjectXML) 

    /**
     * Method clearIoObject
     */
    public void clearIoObject()
    {
        _ioObjectList.clear();
    } //-- void clearIoObject() 

    /**
     * Method enumerateIoObject
     */
    public java.util.Enumeration enumerateIoObject()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_ioObjectList.iterator());
    } //-- java.util.Enumeration enumerateIoObject() 

    /**
     * Method getIoObject
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.IoObjectXML getIoObject(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _ioObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.IoObjectXML) _ioObjectList.get(index);
    } //-- org.openda.core.io.castorgenerated.IoObjectXML getIoObject(int) 

    /**
     * Method getIoObject
     */
    public org.openda.core.io.castorgenerated.IoObjectXML[] getIoObject()
    {
        int size = _ioObjectList.size();
        org.openda.core.io.castorgenerated.IoObjectXML[] mArray = new org.openda.core.io.castorgenerated.IoObjectXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.IoObjectXML) _ioObjectList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.IoObjectXML[] getIoObject() 

    /**
     * Method getIoObjectCount
     */
    public int getIoObjectCount()
    {
        return _ioObjectList.size();
    } //-- int getIoObjectCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeIoObject
     * 
     * @param vIoObject
     */
    public boolean removeIoObject(org.openda.core.io.castorgenerated.IoObjectXML vIoObject)
    {
        boolean removed = _ioObjectList.remove(vIoObject);
        return removed;
    } //-- boolean removeIoObject(org.openda.core.io.castorgenerated.IoObjectXML) 

    /**
     * Method setIoObject
     * 
     * @param index
     * @param vIoObject
     */
    public void setIoObject(int index, org.openda.core.io.castorgenerated.IoObjectXML vIoObject)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _ioObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _ioObjectList.set(index, vIoObject);
    } //-- void setIoObject(int, org.openda.core.io.castorgenerated.IoObjectXML) 

    /**
     * Method setIoObject
     * 
     * @param ioObjectArray
     */
    public void setIoObject(org.openda.core.io.castorgenerated.IoObjectXML[] ioObjectArray)
    {
        //-- copy array
        _ioObjectList.clear();
        for (int i = 0; i < ioObjectArray.length; i++) {
            _ioObjectList.add(ioObjectArray[i]);
        }
    } //-- void setIoObject(org.openda.core.io.castorgenerated.IoObjectXML) 

    /**
     * Method unmarshalInputOutputXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.InputOutputXML unmarshalInputOutputXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.InputOutputXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.InputOutputXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.InputOutputXML unmarshalInputOutputXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
