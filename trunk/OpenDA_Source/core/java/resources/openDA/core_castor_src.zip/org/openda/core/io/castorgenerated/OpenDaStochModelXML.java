/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class OpenDaStochModelXML.
 * 
 * @version $Revision$ $Date$
 */
public class OpenDaStochModelXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Set the openda:java class name of the stochastic model.
     */
    private java.lang.String _className;

    /**
     * Specify the directory, relative to the main configuration
     * directory, where the stochastic model configuration files
     * are stored
     */
    private java.lang.String _workingDirectory;

    /**
     * Select one of the options
     */
    private org.openda.core.io.castorgenerated.OpenDaStochModelXMLChoice _openDaStochModelXMLChoice;


      //----------------/
     //- Constructors -/
    //----------------/

    public OpenDaStochModelXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.OpenDaStochModelXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'className'. The field
     * 'className' has the following description: Set the
     * openda:java class name of the stochastic model.
     * 
     * @return the value of field 'className'.
     */
    public java.lang.String getClassName()
    {
        return this._className;
    } //-- java.lang.String getClassName() 

    /**
     * Returns the value of field 'openDaStochModelXMLChoice'. The
     * field 'openDaStochModelXMLChoice' has the following
     * description: Select one of the options
     * 
     * @return the value of field 'openDaStochModelXMLChoice'.
     */
    public org.openda.core.io.castorgenerated.OpenDaStochModelXMLChoice getOpenDaStochModelXMLChoice()
    {
        return this._openDaStochModelXMLChoice;
    } //-- org.openda.core.io.castorgenerated.OpenDaStochModelXMLChoice getOpenDaStochModelXMLChoice() 

    /**
     * Returns the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: Specify
     * the directory, relative to the main configuration directory,
     * where the stochastic model configuration files are stored
     * 
     * @return the value of field 'workingDirectory'.
     */
    public java.lang.String getWorkingDirectory()
    {
        return this._workingDirectory;
    } //-- java.lang.String getWorkingDirectory() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'className'. The field 'className'
     * has the following description: Set the openda:java class
     * name of the stochastic model.
     * 
     * @param className the value of field 'className'.
     */
    public void setClassName(java.lang.String className)
    {
        this._className = className;
    } //-- void setClassName(java.lang.String) 

    /**
     * Sets the value of field 'openDaStochModelXMLChoice'. The
     * field 'openDaStochModelXMLChoice' has the following
     * description: Select one of the options
     * 
     * @param openDaStochModelXMLChoice the value of field
     * 'openDaStochModelXMLChoice'.
     */
    public void setOpenDaStochModelXMLChoice(org.openda.core.io.castorgenerated.OpenDaStochModelXMLChoice openDaStochModelXMLChoice)
    {
        this._openDaStochModelXMLChoice = openDaStochModelXMLChoice;
    } //-- void setOpenDaStochModelXMLChoice(org.openda.core.io.castorgenerated.OpenDaStochModelXMLChoice) 

    /**
     * Sets the value of field 'workingDirectory'. The field
     * 'workingDirectory' has the following description: Specify
     * the directory, relative to the main configuration directory,
     * where the stochastic model configuration files are stored
     * 
     * @param workingDirectory the value of field 'workingDirectory'
     */
    public void setWorkingDirectory(java.lang.String workingDirectory)
    {
        this._workingDirectory = workingDirectory;
    } //-- void setWorkingDirectory(java.lang.String) 

    /**
     * Method unmarshalOpenDaStochModelXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.OpenDaStochModelXML unmarshalOpenDaStochModelXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.OpenDaStochModelXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.OpenDaStochModelXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.OpenDaStochModelXML unmarshalOpenDaStochModelXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
