/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class ExchangeItemXMLItem.
 * 
 * @version $Revision$ $Date$
 */
public class ExchangeItemXMLItem implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify vector of the exchange item
     */
    private org.openda.core.io.castorgenerated.BlackBoxIoVectorXML _vector;

    /**
     * Specify subvector of the exchange item
     */
    private org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML _subVector;


      //----------------/
     //- Constructors -/
    //----------------/

    public ExchangeItemXMLItem() {
        super();
    } //-- org.openda.core.io.castorgenerated.ExchangeItemXMLItem()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'subVector'. The field
     * 'subVector' has the following description: Specify subvector
     * of the exchange item
     * 
     * @return the value of field 'subVector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML getSubVector()
    {
        return this._subVector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML getSubVector() 

    /**
     * Returns the value of field 'vector'. The field 'vector' has
     * the following description: Specify vector of the exchange
     * item
     * 
     * @return the value of field 'vector'.
     */
    public org.openda.core.io.castorgenerated.BlackBoxIoVectorXML getVector()
    {
        return this._vector;
    } //-- org.openda.core.io.castorgenerated.BlackBoxIoVectorXML getVector() 

    /**
     * Sets the value of field 'subVector'. The field 'subVector'
     * has the following description: Specify subvector of the
     * exchange item
     * 
     * @param subVector the value of field 'subVector'.
     */
    public void setSubVector(org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML subVector)
    {
        this._subVector = subVector;
    } //-- void setSubVector(org.openda.core.io.castorgenerated.BlackBoxIoSubVectorXML) 

    /**
     * Sets the value of field 'vector'. The field 'vector' has the
     * following description: Specify vector of the exchange item
     * 
     * @param vector the value of field 'vector'.
     */
    public void setVector(org.openda.core.io.castorgenerated.BlackBoxIoVectorXML vector)
    {
        this._vector = vector;
    } //-- void setVector(org.openda.core.io.castorgenerated.BlackBoxIoVectorXML) 

}
