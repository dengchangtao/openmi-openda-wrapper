/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class BlackBoxTemplateFilesXML.
 * 
 * @version $Revision$ $Date$
 */
public class BlackBoxTemplateFilesXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Specify the file definitions where KEY strings need to be
     * replaced by values. Specify template file and target file.
     */
    private java.util.ArrayList _fileList;


      //----------------/
     //- Constructors -/
    //----------------/

    public BlackBoxTemplateFilesXML() {
        super();
        _fileList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addFile
     * 
     * @param vFile
     */
    public void addFile(org.openda.core.io.castorgenerated.TemplateFileXML vFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _fileList.add(vFile);
    } //-- void addFile(org.openda.core.io.castorgenerated.TemplateFileXML) 

    /**
     * Method addFile
     * 
     * @param index
     * @param vFile
     */
    public void addFile(int index, org.openda.core.io.castorgenerated.TemplateFileXML vFile)
        throws java.lang.IndexOutOfBoundsException
    {
        _fileList.add(index, vFile);
    } //-- void addFile(int, org.openda.core.io.castorgenerated.TemplateFileXML) 

    /**
     * Method clearFile
     */
    public void clearFile()
    {
        _fileList.clear();
    } //-- void clearFile() 

    /**
     * Method enumerateFile
     */
    public java.util.Enumeration enumerateFile()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_fileList.iterator());
    } //-- java.util.Enumeration enumerateFile() 

    /**
     * Method getFile
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.TemplateFileXML getFile(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _fileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.TemplateFileXML) _fileList.get(index);
    } //-- org.openda.core.io.castorgenerated.TemplateFileXML getFile(int) 

    /**
     * Method getFile
     */
    public org.openda.core.io.castorgenerated.TemplateFileXML[] getFile()
    {
        int size = _fileList.size();
        org.openda.core.io.castorgenerated.TemplateFileXML[] mArray = new org.openda.core.io.castorgenerated.TemplateFileXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.TemplateFileXML) _fileList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.TemplateFileXML[] getFile() 

    /**
     * Method getFileCount
     */
    public int getFileCount()
    {
        return _fileList.size();
    } //-- int getFileCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeFile
     * 
     * @param vFile
     */
    public boolean removeFile(org.openda.core.io.castorgenerated.TemplateFileXML vFile)
    {
        boolean removed = _fileList.remove(vFile);
        return removed;
    } //-- boolean removeFile(org.openda.core.io.castorgenerated.TemplateFileXML) 

    /**
     * Method setFile
     * 
     * @param index
     * @param vFile
     */
    public void setFile(int index, org.openda.core.io.castorgenerated.TemplateFileXML vFile)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _fileList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _fileList.set(index, vFile);
    } //-- void setFile(int, org.openda.core.io.castorgenerated.TemplateFileXML) 

    /**
     * Method setFile
     * 
     * @param fileArray
     */
    public void setFile(org.openda.core.io.castorgenerated.TemplateFileXML[] fileArray)
    {
        //-- copy array
        _fileList.clear();
        for (int i = 0; i < fileArray.length; i++) {
            _fileList.add(fileArray[i]);
        }
    } //-- void setFile(org.openda.core.io.castorgenerated.TemplateFileXML) 

    /**
     * Method unmarshalBlackBoxTemplateFilesXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML unmarshalBlackBoxTemplateFilesXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.BlackBoxTemplateFilesXML unmarshalBlackBoxTemplateFilesXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
