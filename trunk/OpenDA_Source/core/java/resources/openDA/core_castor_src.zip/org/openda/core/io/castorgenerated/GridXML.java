/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class GridXML.
 * 
 * @version $Revision$ $Date$
 */
public class GridXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _computationalSpace
     */
    private org.openda.core.io.castorgenerated.ComputationalSpaceXML _computationalSpace;

    /**
     * Field _physicalSpace
     */
    private org.openda.core.io.castorgenerated.PhysicalSpaceXML _physicalSpace;


      //----------------/
     //- Constructors -/
    //----------------/

    public GridXML() {
        super();
    } //-- org.openda.core.io.castorgenerated.GridXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'computationalSpace'.
     * 
     * @return the value of field 'computationalSpace'.
     */
    public org.openda.core.io.castorgenerated.ComputationalSpaceXML getComputationalSpace()
    {
        return this._computationalSpace;
    } //-- org.openda.core.io.castorgenerated.ComputationalSpaceXML getComputationalSpace() 

    /**
     * Returns the value of field 'physicalSpace'.
     * 
     * @return the value of field 'physicalSpace'.
     */
    public org.openda.core.io.castorgenerated.PhysicalSpaceXML getPhysicalSpace()
    {
        return this._physicalSpace;
    } //-- org.openda.core.io.castorgenerated.PhysicalSpaceXML getPhysicalSpace() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'computationalSpace'.
     * 
     * @param computationalSpace the value of field
     * 'computationalSpace'.
     */
    public void setComputationalSpace(org.openda.core.io.castorgenerated.ComputationalSpaceXML computationalSpace)
    {
        this._computationalSpace = computationalSpace;
    } //-- void setComputationalSpace(org.openda.core.io.castorgenerated.ComputationalSpaceXML) 

    /**
     * Sets the value of field 'physicalSpace'.
     * 
     * @param physicalSpace the value of field 'physicalSpace'.
     */
    public void setPhysicalSpace(org.openda.core.io.castorgenerated.PhysicalSpaceXML physicalSpace)
    {
        this._physicalSpace = physicalSpace;
    } //-- void setPhysicalSpace(org.openda.core.io.castorgenerated.PhysicalSpaceXML) 

    /**
     * Method unmarshalGridXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.GridXML unmarshalGridXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.GridXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.GridXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.GridXML unmarshalGridXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
