/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class PhysicalSpaceXML.
 * 
 * @version $Revision$ $Date$
 */
public class PhysicalSpaceXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Field _dimensionList
     */
    private java.util.ArrayList _dimensionList;


      //----------------/
     //- Constructors -/
    //----------------/

    public PhysicalSpaceXML() {
        super();
        _dimensionList = new ArrayList();
    } //-- org.openda.core.io.castorgenerated.PhysicalSpaceXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addDimension
     * 
     * @param vDimension
     */
    public void addDimension(org.openda.core.io.castorgenerated.PhysicalDimensionXML vDimension)
        throws java.lang.IndexOutOfBoundsException
    {
        _dimensionList.add(vDimension);
    } //-- void addDimension(org.openda.core.io.castorgenerated.PhysicalDimensionXML) 

    /**
     * Method addDimension
     * 
     * @param index
     * @param vDimension
     */
    public void addDimension(int index, org.openda.core.io.castorgenerated.PhysicalDimensionXML vDimension)
        throws java.lang.IndexOutOfBoundsException
    {
        _dimensionList.add(index, vDimension);
    } //-- void addDimension(int, org.openda.core.io.castorgenerated.PhysicalDimensionXML) 

    /**
     * Method clearDimension
     */
    public void clearDimension()
    {
        _dimensionList.clear();
    } //-- void clearDimension() 

    /**
     * Method enumerateDimension
     */
    public java.util.Enumeration enumerateDimension()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_dimensionList.iterator());
    } //-- java.util.Enumeration enumerateDimension() 

    /**
     * Method getDimension
     * 
     * @param index
     */
    public org.openda.core.io.castorgenerated.PhysicalDimensionXML getDimension(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dimensionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.core.io.castorgenerated.PhysicalDimensionXML) _dimensionList.get(index);
    } //-- org.openda.core.io.castorgenerated.PhysicalDimensionXML getDimension(int) 

    /**
     * Method getDimension
     */
    public org.openda.core.io.castorgenerated.PhysicalDimensionXML[] getDimension()
    {
        int size = _dimensionList.size();
        org.openda.core.io.castorgenerated.PhysicalDimensionXML[] mArray = new org.openda.core.io.castorgenerated.PhysicalDimensionXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.core.io.castorgenerated.PhysicalDimensionXML) _dimensionList.get(index);
        }
        return mArray;
    } //-- org.openda.core.io.castorgenerated.PhysicalDimensionXML[] getDimension() 

    /**
     * Method getDimensionCount
     */
    public int getDimensionCount()
    {
        return _dimensionList.size();
    } //-- int getDimensionCount() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeDimension
     * 
     * @param vDimension
     */
    public boolean removeDimension(org.openda.core.io.castorgenerated.PhysicalDimensionXML vDimension)
    {
        boolean removed = _dimensionList.remove(vDimension);
        return removed;
    } //-- boolean removeDimension(org.openda.core.io.castorgenerated.PhysicalDimensionXML) 

    /**
     * Method setDimension
     * 
     * @param index
     * @param vDimension
     */
    public void setDimension(int index, org.openda.core.io.castorgenerated.PhysicalDimensionXML vDimension)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _dimensionList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _dimensionList.set(index, vDimension);
    } //-- void setDimension(int, org.openda.core.io.castorgenerated.PhysicalDimensionXML) 

    /**
     * Method setDimension
     * 
     * @param dimensionArray
     */
    public void setDimension(org.openda.core.io.castorgenerated.PhysicalDimensionXML[] dimensionArray)
    {
        //-- copy array
        _dimensionList.clear();
        for (int i = 0; i < dimensionArray.length; i++) {
            _dimensionList.add(dimensionArray[i]);
        }
    } //-- void setDimension(org.openda.core.io.castorgenerated.PhysicalDimensionXML) 

    /**
     * Method unmarshalPhysicalSpaceXML
     * 
     * @param reader
     */
    public static org.openda.core.io.castorgenerated.PhysicalSpaceXML unmarshalPhysicalSpaceXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.core.io.castorgenerated.PhysicalSpaceXML) Unmarshaller.unmarshal(org.openda.core.io.castorgenerated.PhysicalSpaceXML.class, reader);
    } //-- org.openda.core.io.castorgenerated.PhysicalSpaceXML unmarshalPhysicalSpaceXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
