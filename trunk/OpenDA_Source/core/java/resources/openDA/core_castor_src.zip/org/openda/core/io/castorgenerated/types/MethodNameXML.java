/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.core.io.castorgenerated.types;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class MethodNameXML.
 * 
 * @version $Revision$ $Date$
 */
public class MethodNameXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The dud type
     */
    public static final int DUD_TYPE = 0;

    /**
     * The instance of the dud type
     */
    public static final MethodNameXML DUD = new MethodNameXML(DUD_TYPE, "dud");

    /**
     * The powell type
     */
    public static final int POWELL_TYPE = 1;

    /**
     * The instance of the powell type
     */
    public static final MethodNameXML POWELL = new MethodNameXML(POWELL_TYPE, "powell");

    /**
     * The simplex type
     */
    public static final int SIMPLEX_TYPE = 2;

    /**
     * The instance of the simplex type
     */
    public static final MethodNameXML SIMPLEX = new MethodNameXML(SIMPLEX_TYPE, "simplex");

    /**
     * Field _memberTable
     */
    private static java.util.Hashtable _memberTable = init();

    /**
     * Field type
     */
    private int type = -1;

    /**
     * Field stringValue
     */
    private java.lang.String stringValue = null;


      //----------------/
     //- Constructors -/
    //----------------/

    private MethodNameXML(int type, java.lang.String value) {
        super();
        this.type = type;
        this.stringValue = value;
    } //-- org.openda.core.io.castorgenerated.types.MethodNameXML(int, java.lang.String)


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method enumerateReturns an enumeration of all possible
     * instances of MethodNameXML
     */
    public static java.util.Enumeration enumerate()
    {
        return _memberTable.elements();
    } //-- java.util.Enumeration enumerate() 

    /**
     * Method getTypeReturns the type of this MethodNameXML
     */
    public int getType()
    {
        return this.type;
    } //-- int getType() 

    /**
     * Method init
     */
    private static java.util.Hashtable init()
    {
        Hashtable members = new Hashtable();
        members.put("dud", DUD);
        members.put("powell", POWELL);
        members.put("simplex", SIMPLEX);
        return members;
    } //-- java.util.Hashtable init() 

    /**
     * Method toStringReturns the String representation of this
     * MethodNameXML
     */
    public java.lang.String toString()
    {
        return this.stringValue;
    } //-- java.lang.String toString() 

    /**
     * Method valueOfReturns a new MethodNameXML based on the given
     * String value.
     * 
     * @param string
     */
    public static org.openda.core.io.castorgenerated.types.MethodNameXML valueOf(java.lang.String string)
    {
        java.lang.Object obj = null;
        if (string != null) obj = _memberTable.get(string);
        if (obj == null) {
            String err = "'" + string + "' is not a valid MethodNameXML";
            throw new IllegalArgumentException(err);
        }
        return (MethodNameXML) obj;
    } //-- org.openda.core.io.castorgenerated.types.MethodNameXML valueOf(java.lang.String) 

}
