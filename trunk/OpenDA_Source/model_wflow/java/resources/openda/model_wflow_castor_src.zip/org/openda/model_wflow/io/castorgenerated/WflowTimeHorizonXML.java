/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_wflow.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class WflowTimeHorizonXML.
 * 
 * @version $Revision$ $Date$
 */
public class WflowTimeHorizonXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * Start of the model run.
     */
    private org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML _startDateTime;

    /**
     * End of the model run.
     */
    private org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML _endDateTime;

    /**
     * The time zone in which the startDateTime and endDateTime of
     * the model run are specified. This should be the offset of
     * the timeZone with respect to GMT, in hours between -12 and 12
     */
    private double _timeZoneOffset;

    /**
     * keeps track of state for field: _timeZoneOffset
     */
    private boolean _has_timeZoneOffset;


      //----------------/
     //- Constructors -/
    //----------------/

    public WflowTimeHorizonXML() {
        super();
    } //-- org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Returns the value of field 'endDateTime'. The field
     * 'endDateTime' has the following description: End of the
     * model run.
     * 
     * @return the value of field 'endDateTime'.
     */
    public org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML getEndDateTime()
    {
        return this._endDateTime;
    } //-- org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML getEndDateTime() 

    /**
     * Returns the value of field 'startDateTime'. The field
     * 'startDateTime' has the following description: Start of the
     * model run.
     * 
     * @return the value of field 'startDateTime'.
     */
    public org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML getStartDateTime()
    {
        return this._startDateTime;
    } //-- org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML getStartDateTime() 

    /**
     * Returns the value of field 'timeZoneOffset'. The field
     * 'timeZoneOffset' has the following description: The time
     * zone in which the startDateTime and endDateTime of the model
     * run are specified. This should be the offset of the timeZone
     * with respect to GMT, in hours between -12 and 12.
     * 
     * @return the value of field 'timeZoneOffset'.
     */
    public double getTimeZoneOffset()
    {
        return this._timeZoneOffset;
    } //-- double getTimeZoneOffset() 

    /**
     * Method hasTimeZoneOffset
     */
    public boolean hasTimeZoneOffset()
    {
        return this._has_timeZoneOffset;
    } //-- boolean hasTimeZoneOffset() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Sets the value of field 'endDateTime'. The field
     * 'endDateTime' has the following description: End of the
     * model run.
     * 
     * @param endDateTime the value of field 'endDateTime'.
     */
    public void setEndDateTime(org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML endDateTime)
    {
        this._endDateTime = endDateTime;
    } //-- void setEndDateTime(org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML) 

    /**
     * Sets the value of field 'startDateTime'. The field
     * 'startDateTime' has the following description: Start of the
     * model run.
     * 
     * @param startDateTime the value of field 'startDateTime'.
     */
    public void setStartDateTime(org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML startDateTime)
    {
        this._startDateTime = startDateTime;
    } //-- void setStartDateTime(org.openda.model_wflow.io.castorgenerated.WflowDateTimeXML) 

    /**
     * Sets the value of field 'timeZoneOffset'. The field
     * 'timeZoneOffset' has the following description: The time
     * zone in which the startDateTime and endDateTime of the model
     * run are specified. This should be the offset of the timeZone
     * with respect to GMT, in hours between -12 and 12.
     * 
     * @param timeZoneOffset the value of field 'timeZoneOffset'.
     */
    public void setTimeZoneOffset(double timeZoneOffset)
    {
        this._timeZoneOffset = timeZoneOffset;
        this._has_timeZoneOffset = true;
    } //-- void setTimeZoneOffset(double) 

    /**
     * Method unmarshalWflowTimeHorizonXML
     * 
     * @param reader
     */
    public static org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML unmarshalWflowTimeHorizonXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML) Unmarshaller.unmarshal(org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML.class, reader);
    } //-- org.openda.model_wflow.io.castorgenerated.WflowTimeHorizonXML unmarshalWflowTimeHorizonXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
