/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.model_wflow.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.Serializable;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;

/**
 * Class WflowDateXML.
 * 
 * @version $Revision$ $Date$
 */
public class WflowDateXML implements java.io.Serializable {


      //----------------/
     //- Constructors -/
    //----------------/

    public WflowDateXML() {
        super();
    } //-- org.openda.model_wflow.io.castorgenerated.WflowDateXML()

}
