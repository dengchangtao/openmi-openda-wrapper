/*
 * This class was automatically generated with 
 * <a href="http://www.castor.org">Castor 0.9.4.3</a>, using an XML
 * Schema.
 * $Id$
 */

package org.openda.observers.io.castorgenerated;

  //---------------------------------/
 //- Imported classes and packages -/
//---------------------------------/

import java.io.IOException;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Enumeration;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

/**
 * Class IoObjectStochObserverXML.
 * 
 * @version $Revision$ $Date$
 */
public class IoObjectStochObserverXML implements java.io.Serializable {


      //--------------------------/
     //- Class/Member Variables -/
    //--------------------------/

    /**
     * The uncertainty module to be started (e.g.
     * org.openda.uncertainties.UncertaintyEngine).
     */
    private org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML _uncertaintyModule;

    /**
     * One or more IO objects. The firstargument of each IO object
     * is interpreted as the file to be read
     */
    private java.util.ArrayList _ioObjectList;

    /**
     * Field _assimilationStations
     */
    private org.openda.observers.io.castorgenerated.StochObservationStationsXML _assimilationStations;

    /**
     * Field _validationStations
     */
    private org.openda.observers.io.castorgenerated.StochObservationStationsXML _validationStations;

    /**
     * Should missing values in the observations be removed, or
     * should they be presented as NaN?
     */
    private boolean _removeMissingValues = true;

    /**
     * keeps track of state for field: _removeMissingValues
     */
    private boolean _has_removeMissingValues;


      //----------------/
     //- Constructors -/
    //----------------/

    public IoObjectStochObserverXML() {
        super();
        _ioObjectList = new ArrayList();
    } //-- org.openda.observers.io.castorgenerated.IoObjectStochObserverXML()


      //-----------/
     //- Methods -/
    //-----------/

    /**
     * Method addIoObject
     * 
     * @param vIoObject
     */
    public void addIoObject(org.openda.observers.io.castorgenerated.StochObsIoObjectXML vIoObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _ioObjectList.add(vIoObject);
    } //-- void addIoObject(org.openda.observers.io.castorgenerated.StochObsIoObjectXML) 

    /**
     * Method addIoObject
     * 
     * @param index
     * @param vIoObject
     */
    public void addIoObject(int index, org.openda.observers.io.castorgenerated.StochObsIoObjectXML vIoObject)
        throws java.lang.IndexOutOfBoundsException
    {
        _ioObjectList.add(index, vIoObject);
    } //-- void addIoObject(int, org.openda.observers.io.castorgenerated.StochObsIoObjectXML) 

    /**
     * Method clearIoObject
     */
    public void clearIoObject()
    {
        _ioObjectList.clear();
    } //-- void clearIoObject() 

    /**
     * Method deleteRemoveMissingValues
     */
    public void deleteRemoveMissingValues()
    {
        this._has_removeMissingValues= false;
    } //-- void deleteRemoveMissingValues() 

    /**
     * Method enumerateIoObject
     */
    public java.util.Enumeration enumerateIoObject()
    {
        return new org.exolab.castor.util.IteratorEnumeration(_ioObjectList.iterator());
    } //-- java.util.Enumeration enumerateIoObject() 

    /**
     * Returns the value of field 'assimilationStations'.
     * 
     * @return the value of field 'assimilationStations'.
     */
    public org.openda.observers.io.castorgenerated.StochObservationStationsXML getAssimilationStations()
    {
        return this._assimilationStations;
    } //-- org.openda.observers.io.castorgenerated.StochObservationStationsXML getAssimilationStations() 

    /**
     * Method getIoObject
     * 
     * @param index
     */
    public org.openda.observers.io.castorgenerated.StochObsIoObjectXML getIoObject(int index)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _ioObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        
        return (org.openda.observers.io.castorgenerated.StochObsIoObjectXML) _ioObjectList.get(index);
    } //-- org.openda.observers.io.castorgenerated.StochObsIoObjectXML getIoObject(int) 

    /**
     * Method getIoObject
     */
    public org.openda.observers.io.castorgenerated.StochObsIoObjectXML[] getIoObject()
    {
        int size = _ioObjectList.size();
        org.openda.observers.io.castorgenerated.StochObsIoObjectXML[] mArray = new org.openda.observers.io.castorgenerated.StochObsIoObjectXML[size];
        for (int index = 0; index < size; index++) {
            mArray[index] = (org.openda.observers.io.castorgenerated.StochObsIoObjectXML) _ioObjectList.get(index);
        }
        return mArray;
    } //-- org.openda.observers.io.castorgenerated.StochObsIoObjectXML[] getIoObject() 

    /**
     * Method getIoObjectCount
     */
    public int getIoObjectCount()
    {
        return _ioObjectList.size();
    } //-- int getIoObjectCount() 

    /**
     * Returns the value of field 'removeMissingValues'. The field
     * 'removeMissingValues' has the following description: Should
     * missing values in the observations be removed, or should
     * they be presented as NaN?
     * 
     * @return the value of field 'removeMissingValues'.
     */
    public boolean getRemoveMissingValues()
    {
        return this._removeMissingValues;
    } //-- boolean getRemoveMissingValues() 

    /**
     * Returns the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: The
     * uncertainty module to be started (e.g.
     * org.openda.uncertainties.UncertaintyEngine).
     * 
     * @return the value of field 'uncertaintyModule'.
     */
    public org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML getUncertaintyModule()
    {
        return this._uncertaintyModule;
    } //-- org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML getUncertaintyModule() 

    /**
     * Returns the value of field 'validationStations'.
     * 
     * @return the value of field 'validationStations'.
     */
    public org.openda.observers.io.castorgenerated.StochObservationStationsXML getValidationStations()
    {
        return this._validationStations;
    } //-- org.openda.observers.io.castorgenerated.StochObservationStationsXML getValidationStations() 

    /**
     * Method hasRemoveMissingValues
     */
    public boolean hasRemoveMissingValues()
    {
        return this._has_removeMissingValues;
    } //-- boolean hasRemoveMissingValues() 

    /**
     * Method isValid
     */
    public boolean isValid()
    {
        try {
            validate();
        }
        catch (org.exolab.castor.xml.ValidationException vex) {
            return false;
        }
        return true;
    } //-- boolean isValid() 

    /**
     * Method marshal
     * 
     * @param out
     */
    public void marshal(java.io.Writer out)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, out);
    } //-- void marshal(java.io.Writer) 

    /**
     * Method marshal
     * 
     * @param handler
     */
    public void marshal(org.xml.sax.ContentHandler handler)
        throws java.io.IOException, org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        
        Marshaller.marshal(this, handler);
    } //-- void marshal(org.xml.sax.ContentHandler) 

    /**
     * Method removeIoObject
     * 
     * @param vIoObject
     */
    public boolean removeIoObject(org.openda.observers.io.castorgenerated.StochObsIoObjectXML vIoObject)
    {
        boolean removed = _ioObjectList.remove(vIoObject);
        return removed;
    } //-- boolean removeIoObject(org.openda.observers.io.castorgenerated.StochObsIoObjectXML) 

    /**
     * Sets the value of field 'assimilationStations'.
     * 
     * @param assimilationStations the value of field
     * 'assimilationStations'.
     */
    public void setAssimilationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML assimilationStations)
    {
        this._assimilationStations = assimilationStations;
    } //-- void setAssimilationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML) 

    /**
     * Method setIoObject
     * 
     * @param index
     * @param vIoObject
     */
    public void setIoObject(int index, org.openda.observers.io.castorgenerated.StochObsIoObjectXML vIoObject)
        throws java.lang.IndexOutOfBoundsException
    {
        //-- check bounds for index
        if ((index < 0) || (index > _ioObjectList.size())) {
            throw new IndexOutOfBoundsException();
        }
        _ioObjectList.set(index, vIoObject);
    } //-- void setIoObject(int, org.openda.observers.io.castorgenerated.StochObsIoObjectXML) 

    /**
     * Method setIoObject
     * 
     * @param ioObjectArray
     */
    public void setIoObject(org.openda.observers.io.castorgenerated.StochObsIoObjectXML[] ioObjectArray)
    {
        //-- copy array
        _ioObjectList.clear();
        for (int i = 0; i < ioObjectArray.length; i++) {
            _ioObjectList.add(ioObjectArray[i]);
        }
    } //-- void setIoObject(org.openda.observers.io.castorgenerated.StochObsIoObjectXML) 

    /**
     * Sets the value of field 'removeMissingValues'. The field
     * 'removeMissingValues' has the following description: Should
     * missing values in the observations be removed, or should
     * they be presented as NaN?
     * 
     * @param removeMissingValues the value of field
     * 'removeMissingValues'.
     */
    public void setRemoveMissingValues(boolean removeMissingValues)
    {
        this._removeMissingValues = removeMissingValues;
        this._has_removeMissingValues = true;
    } //-- void setRemoveMissingValues(boolean) 

    /**
     * Sets the value of field 'uncertaintyModule'. The field
     * 'uncertaintyModule' has the following description: The
     * uncertainty module to be started (e.g.
     * org.openda.uncertainties.UncertaintyEngine).
     * 
     * @param uncertaintyModule the value of field
     * 'uncertaintyModule'.
     */
    public void setUncertaintyModule(org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML uncertaintyModule)
    {
        this._uncertaintyModule = uncertaintyModule;
    } //-- void setUncertaintyModule(org.openda.observers.io.castorgenerated.StochObsUncertaintyModuleXML) 

    /**
     * Sets the value of field 'validationStations'.
     * 
     * @param validationStations the value of field
     * 'validationStations'.
     */
    public void setValidationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML validationStations)
    {
        this._validationStations = validationStations;
    } //-- void setValidationStations(org.openda.observers.io.castorgenerated.StochObservationStationsXML) 

    /**
     * Method unmarshalIoObjectStochObserverXML
     * 
     * @param reader
     */
    public static org.openda.observers.io.castorgenerated.IoObjectStochObserverXML unmarshalIoObjectStochObserverXML(java.io.Reader reader)
        throws org.exolab.castor.xml.MarshalException, org.exolab.castor.xml.ValidationException
    {
        return (org.openda.observers.io.castorgenerated.IoObjectStochObserverXML) Unmarshaller.unmarshal(org.openda.observers.io.castorgenerated.IoObjectStochObserverXML.class, reader);
    } //-- org.openda.observers.io.castorgenerated.IoObjectStochObserverXML unmarshalIoObjectStochObserverXML(java.io.Reader) 

    /**
     * Method validate
     */
    public void validate()
        throws org.exolab.castor.xml.ValidationException
    {
        org.exolab.castor.xml.Validator validator = new org.exolab.castor.xml.Validator();
        validator.validate(this);
    } //-- void validate() 

}
